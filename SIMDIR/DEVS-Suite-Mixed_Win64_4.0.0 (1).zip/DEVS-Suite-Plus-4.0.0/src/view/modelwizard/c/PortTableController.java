package view.modelwizard.c;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import view.modelwizard.CheckboxHeader;
import view.modelwizard.v.PortTableView;

public class PortTableController
{
    private PortTableView view;
    
    public PortTableController(PortTableView view)
    {
        this.view = view;
    }
    
    public ChangeListener onCheckboxClicked(CheckboxHeader newHeader)
    {
        return new ChangeListener() {

            @Override
            public void stateChanged(ChangeEvent e)
            {
                if(e.getSource() == newHeader && newHeader.isSelected())
                {
                    for (CheckboxHeader header : view.getCheckboxHeaders())
                    {
                        if(newHeader != header && header.isSelected())
                        {
                            header.setSelected(false);
                        }
                    }
                }
            }
            
        };
    }
}
