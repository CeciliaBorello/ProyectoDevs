package view.modelwizard;

import view.View;
import view.modelwizard.v.ModelWizardView;

public class ModelWizard
{   
    private View view;
    private ModelWizardView modelWizardDialog;
   
    public ModelWizard(View view)
    {
    	this.view = view;
    }
    
    public void openDialog()
    {
    	modelWizardDialog = new ModelWizardView(view);
        modelWizardDialog.setVisible(true);
    }
    
    public boolean isSimView()
    {
    	return this.modelWizardDialog.isSimViewSelected();
    }
    
    public boolean isTracking()
    {
    	return this.modelWizardDialog.isTrackingEnabled();
    }
    
    public boolean isCATracking()
    {
    	return this.modelWizardDialog.isCATrackingEnabled();
    }
    
    public void disableSimView()
    {
    	this.modelWizardDialog.getFirstPage().getModel().checkboxOptions.setSimViewFalse();
    }
    
    public void disableTracking()
    {
    	this.modelWizardDialog.getFirstPage().getModel().checkboxOptions.setTrackingFalse();
    }
    
    public void enableSimView()
    {
    	this.modelWizardDialog.getFirstPage().getModel().checkboxOptions.setSimViewTrue();
    }
    
    public void enableTracking()
    {
    	this.modelWizardDialog.getFirstPage().getModel().checkboxOptions.setTrackingTrue();
    }
    
    public String getSourcePath()
    {
    	return this.modelWizardDialog.getFirstPage().getModel().fileSystemConfiguration.getSourcePath();
    }
}