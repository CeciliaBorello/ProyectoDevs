package view;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;

import controller.TrackingDataHandler;
import facade.modeling.FModel;

public class ModelTrackingDataHandler implements TrackingDataHandler {
    private ModelTrackingComponent trackingComponent;
    private FModelView modelView;

	public ModelTrackingDataHandler(FModelView modelView)
	{
		this.modelView = modelView;
	}

	public void registerTrackingComponent(ModelTrackingComponent trackingComponent)
	{
		this.trackingComponent = trackingComponent;
	}

    public String getHTMLTrackingLog() 
    {
        return trackingComponent.getHTMLString();
    }

    public String[] getEncodedCSVExport() 
    {
        FModel model = modelView.getSelectedModel();

        int seed = 0;
        StringBuffer legend = new StringBuffer();

        legend.append("<HTML><BODY><B>Legend - " + model.getName() + "</B>");
        Hashtable hashtable = new Hashtable();
        Tracker tracker  = trackingComponent.findTrackerFor(model);
        String[] headers = tracker.getDataHeaders();
        List[] dataStore = tracker.getDataStorage();
        List[] encodedDataStore = new List[dataStore.length];
        {
            encodedDataStore[0] = ViewUtils.integerEncode(dataStore[0],hashtable,seed);
            seed += 100;
            legend.append("<P><B>"+headers[0]+"</B>");
            legend.append("<TABLE BORDER=\"1\" CELLPADDING=\"5\" CELLSPACING=\"1\" ");
            legend.append("bordercolorlight=\"#C0C0C0\" bordercolordark=\"#C0C0C0\" bordercolor=\"#C0C0C0\" >");
            legend.append("<TR><TD width=\"100\"><B>Key</B></TD>");
            legend.append("<TD width=\"100\"><B>Value</B></TD></TR>");

            Iterator it = hashtable.keySet().iterator();
            while(it.hasNext())
            {
                 Object key = it.next();
                 legend.append("<TR><TD nowrap>" + key + "</TD>");
                 legend.append("<TD nowrap>" + hashtable.get(key) + "</TD></TR>");
            }
            hashtable.clear();
            legend.append("</TABLE>");
        }
        encodedDataStore[1] = dataStore[1];
        encodedDataStore[2] = dataStore[2];
        encodedDataStore[3] = dataStore[3];

        for (int i = 4; i < dataStore.length; i++)
        {
            encodedDataStore[i] = ViewUtils.integerEncode(dataStore[i],hashtable,seed);
            seed += 100;
            legend.append("<P><B>"+headers[i]+"</B>");
            legend.append("<TABLE BORDER=\"1\" CELLPADDING=\"5\" CELLSPACING=\"1\" ");
            legend.append("bordercolorlight=\"#C0C0C0\" bordercolordark=\"#C0C0C0\" bordercolor=\"#C0C0C0\" >");
            legend.append("<TR><TD width=\"100\"><B>Key</B></TD>");
            legend.append("<TD width=\"100\"><B>Value</B></TD></TR>");

            Iterator it = hashtable.keySet().iterator();
            while(it.hasNext())
            {
                Object key = it.next();
                legend.append("<TR><TD nowrap>" + key + "</TD>");
                legend.append("<TD nowrap>" + hashtable.get(key) + "</TD></TR>");
            }
            hashtable.clear();
            legend.append("</TABLE>");
        }

        legend.append("</BODY></HTML>");

        String[] val = new String[2];
        val[0] = legend.toString();
        val[1] = createCSVString(headers,encodedDataStore);
        return val;
    }

    public String getCSVExport() 
    {
        Tracker tracker = trackingComponent.findTrackerFor(modelView.getSelectedModel());
        return createCSVString(tracker.getDataHeaders(),tracker.getDataStorage());
    }

    private String createCSVString(String[] headers,List[] storage)
    {    
        String delim = ",";
        String newLine = "\n";
        StringBuffer buffer = new StringBuffer();

        List headerRow = trackingComponent.getHeaderRow();

        buffer.append(delim);
        for (int i = 0; i < headers.length; i++)
        {
            buffer.append(headers[i]);
            buffer.append(delim);
        }
        buffer.append(newLine);

        int length = headerRow.size()-1;
        for (int i = 0; i < length; i++)
        {
            buffer.append(headerRow.get(i+1));
            buffer.append(delim);
            for (int j = 0; j < storage.length; j++)
            {  
                Object obj = storage[j].get(i);
                buffer.append((obj == null) ? "" : obj.toString());
                buffer.append(delim);
            }
            buffer.append(newLine);
        }
        return buffer.toString();
    }
}
