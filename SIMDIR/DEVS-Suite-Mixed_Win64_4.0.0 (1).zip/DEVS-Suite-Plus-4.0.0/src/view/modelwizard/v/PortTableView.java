package view.modelwizard.v;

import java.util.ArrayList;

import javax.swing.JTable;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

import view.modelwizard.CheckboxHeader;
import view.modelwizard.c.PortTableController;

public class PortTableView extends JTable
{
    private static final long serialVersionUID = 293755575539538192L;
    private boolean[] portsStacked, portsSeparate;
    private String[] units;
    private ArrayList<CheckboxHeader> checkboxHeaders;
    private PortTableController controller;

    public PortTableView(Object[][] data, Object[] col, boolean[] portsStacked, boolean[] portsSeparate, String[] units)
    {
        super(new DefaultTableModel(data, col));
        this.portsStacked = portsStacked;
        this.portsSeparate = portsSeparate;
        this.units = units;

        this.checkboxHeaders = new ArrayList<CheckboxHeader>();

        createController();
        setupCheckboxHeaders();
    }

    public void createController()
    {
        this.controller = new PortTableController(this);
    }

    public ArrayList<CheckboxHeader> getCheckboxHeaders()
    {
        return this.checkboxHeaders;
    }

    private void setupCheckboxHeaders()
    {
        ArrayList<String> columnNames = new ArrayList<String>();

        for (int i = 0; i < this.getColumnCount(); ++i)
        {
            if (this.getColumnName(i).toLowerCase().contains("stack")
                    || this.getColumnName(i).toLowerCase().contains("separate"))
            {
                columnNames.add(this.getColumnName(i));
                TableColumn column = this.getColumnModel().getColumn(i);

                CheckboxHeader newHeader = new CheckboxHeader(this.getColumnName(i), this);
                newHeader.addChangeListener(controller.onCheckboxClicked(newHeader));
                this.checkboxHeaders.add(newHeader);
                column.setHeaderRenderer(newHeader);
            }
        }
    }

    public int getColumnIndexByName(String name)
    {
        for (int i = 0; i < getColumnCount(); ++i)
        {
            if (getColumnName(i).equals(name))
            {
                return i;
            }
        }

        return -1;
    }

    @Override
    public boolean isCellEditable(int arg0, int arg1)
    {
        return (arg1 > 0 || arg1 < 4);
    }

    @Override
    public void setValueAt(Object aValue, int rowIndex, int columnIndex)
    {
        final int _units = getColumnIndexByName("Units");
        final int _stack = getColumnIndexByName("Stack");
        final int _separate = getColumnIndexByName("Separate");

        if(columnIndex == _units)
        {
            if (aValue != null)
            {
                units[rowIndex] = (String) aValue;
            }
        }
        else if(columnIndex == _stack)
        {
            portsStacked[rowIndex] = (boolean) aValue;
            if ((boolean) aValue)
            {
                getModel().setValueAt(false, rowIndex, 3);
            }
        }
        else if(columnIndex == _separate)
        {
            portsSeparate[rowIndex] = (boolean) aValue;
            if ((boolean) aValue)
            {
                getModel().setValueAt(false, rowIndex, 2);
            }
        }

        super.setValueAt(aValue,rowIndex,columnIndex);
    }

    @Override
    public Class<?> getColumnClass(int column)
    {
        switch (column)
        {
        case 0:
            return String.class;
        case 1:
            return String.class;
        case 2:
            return Boolean.class;
        case 3:
            return Boolean.class;

        }
        return null;
    }
}
