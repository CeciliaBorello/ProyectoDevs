package view.modelwizard.v;

import javax.swing.JDialog;

import view.View;
import view.jwizard.WizardContainer;
import view.jwizard.WizardPage;
import view.jwizard.pagetemplates.TitledPageTemplate;
import view.modelwizard.ModelWizardPageFactory;
import view.modelwizard.c.ModelWizardController;
import view.modelwizard.m.ModelWizardModel;

public class ModelWizardView extends JDialog
{
	private static final long serialVersionUID = 2614027297450099521L;
	private ModelWizardController modelWizardController;
	private ModelWizardPageFactory pageFactory;
	private WizardContainer wizardContainer;
	private View parent;
	
	public ModelWizardView(View parent)
	{
		this.createController();
		this.parent = parent;
		
		this.pageFactory = new ModelWizardPageFactory(this);
		this.wizardContainer = new WizardContainer(pageFactory, new TitledPageTemplate());
		this.wizardContainer.addWizardListener(getController().onWizardPageChanged);
		this.setResizable(false);
	      
	    this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	    this.getContentPane().add(wizardContainer);
	    this.setSize(650,600);
	}
	
	public ModelWizardPageFactory getPageFactory()
	{
		return this.pageFactory;
	}
	
	public WizardPage getCurrentPage()
	{
		return this.wizardContainer.getPath().get(this.wizardContainer.getPath().size() - 1);
	}
	
	public boolean isTrackingEnabled()
	{
		if(this.pageFactory.getFirstPage() != null)
		{
			return getFirstPage().getCheckboxOptions().getModel().isTrackingSelected();
		}
		else
		{
			return false;
		}
	}
	
	public boolean isSimViewSelected()
	{
		if(getFirstPage() != null)
		{
			return getFirstPage().getCheckboxOptions().getModel().isSimViewSelected();
		}
		else
		{
			return false;
		}
	}
	
	public boolean isCATrackingEnabled()
	{
		if(getFirstPage() != null)
		{
			return getFirstPage().getCheckboxOptions().getModel().isCAModel();
		}
		else
		{
			return false;
		}
	}
	
	public InitialConfigurationPageView getFirstPage()
	{
		return this.pageFactory.getFirstPage();
	}
	
	private void createController()
	{
		this.modelWizardController = new ModelWizardController(this);
	}
	
	public ModelWizardController getController()
	{
		return this.modelWizardController;
	}
	
	public ModelWizardModel getModel()
	{
		return this.getController().getModel();
	}
	
	public View getParentView()
	{
		return this.parent;
	}
}
