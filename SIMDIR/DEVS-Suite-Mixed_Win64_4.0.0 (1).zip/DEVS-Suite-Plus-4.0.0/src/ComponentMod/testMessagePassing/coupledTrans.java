package ComponentMod.testMessagePassing;

import GenCol.entity;
import view.modeling.ViewableAtomic;
import view.modeling.ViewableDigraph;

public class coupledTrans extends ViewableDigraph {

	public coupledTrans() {
		super("coupledTrans");

		ViewableAtomic t = new transducer("Transducer", 200);

		add(t);

		addInport("in");


		addCoupling(this, "in", t, "in");

	}
} 