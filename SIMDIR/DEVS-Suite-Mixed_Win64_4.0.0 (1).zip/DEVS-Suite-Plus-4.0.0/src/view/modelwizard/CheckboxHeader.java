package view.modelwizard;

import java.awt.Component;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JCheckBox;
import javax.swing.JTable;
import javax.swing.UIManager;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumnModel;

import view.modelwizard.v.PortTableView;

public class CheckboxHeader extends JCheckBox implements TableCellRenderer, MouseListener
{
    private String columnName;
    private PortTableView table;
    private boolean mousePressed;
    private static final long serialVersionUID = -8733025129678211995L;

    public CheckboxHeader(String columnName, PortTableView table)
    {
        this.table = table;
        this.mousePressed = false;
        
        this.columnName = columnName;
    }
    
    public void click()
    {
        boolean newValue = !isSelected();
        setSelected(newValue);
        for (int i = 0; i < table.getRowCount(); ++i)
        {
            table.setValueAt(newValue, i, getColumnIndex());
        }
    }
    
    public void mouseClicked(MouseEvent e)
    {
        if(!mousePressed)
        {
            return;
        }
        
        TableColumnModel columnModel = table.getColumnModel();
        if(columnModel.getColumnIndexAtX(e.getX()) == getColumnIndex())
        {
            click();
            mousePressed = false;
        }
    }
    
    public int getColumnIndex()
    {
        return getColumnIndex(this.columnName);
    }
    
    private int getColumnIndex(String columnName)
    {
        return table.getColumnIndexByName(columnName);
    }

    @Override
    public void mouseEntered(MouseEvent arg0)
    {
        //No op
    }

    @Override
    public void mouseExited(MouseEvent arg0)
    {
        //No op
    }

    @Override
    public void mousePressed(MouseEvent arg0)
    {
        mousePressed = true;
    }

    @Override
    public void mouseReleased(MouseEvent arg0)
    {
        //No op
    }

    @Override
    public Component getTableCellRendererComponent(JTable table, Object arg1, boolean arg2, boolean arg3, int arg4,
            int arg5)
    {
        if (table != null) 
        {
            JTableHeader header = table.getTableHeader();
            if (header != null)
            {
                this.setForeground(header.getForeground());
                this.setBackground(header.getBackground());
                this.setFont(header.getFont());
                this.setBorder(header.getBorder());
                setBorderPainted(true);
                setBorderPaintedFlat(true);
                header.addMouseListener(this);
            }
        }
        
        this.setText(columnName);
        setBorder(UIManager.getBorder("TableHeader.cellBorder"));
        return this;
    }

}
