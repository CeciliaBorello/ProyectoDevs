package view.modelwizard.c;

import javax.swing.JTree;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;

import facade.modeling.FModel;
import view.modelwizard.m.ComponentTrackingConfigurationPageModel;
import view.modelwizard.v.ComponentTrackingConfigurationPageView;

public class ComponentTrackingConfigurationPageController
{
	private ComponentTrackingConfigurationPageView view;
	private ComponentTrackingConfigurationPageModel model;

	public ComponentTrackingConfigurationPageController(ComponentTrackingConfigurationPageView view)
	{
		this.view = view;
		this.model = new ComponentTrackingConfigurationPageModel(view);
	}
	
	public ComponentTrackingConfigurationPageModel getModel()
	{
		return this.model;
	}
	
	public TreeSelectionListener onNodeSelected = new TreeSelectionListener() {

		@Override
		public void valueChanged(TreeSelectionEvent e)
		{
			JTree modelHierarchy = (JTree) e.getSource();
			DefaultMutableTreeNode node = (DefaultMutableTreeNode) (modelHierarchy).getLastSelectedPathComponent();
			if (node != null)
			{
				FModel model = (FModel) node.getUserObject();
				
				view.setEast(model);
			}
		}
	};
}
