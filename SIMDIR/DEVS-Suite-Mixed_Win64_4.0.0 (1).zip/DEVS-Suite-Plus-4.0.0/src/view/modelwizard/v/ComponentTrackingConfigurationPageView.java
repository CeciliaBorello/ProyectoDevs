package view.modelwizard.v;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreeNode;

import facade.modeling.FModel;
import view.Tracker;
import view.jwizard.WizardPage;
import view.jwizard.WizardSettings;
import view.modelwizard.ModelHierarchyRenderer;
import view.modelwizard.c.ComponentTrackingConfigurationPageController;
import view.modelwizard.m.ComponentTrackingConfigurationPageModel;

public class ComponentTrackingConfigurationPageView extends WizardPage
{
	private static final long serialVersionUID = -6073601442289086136L;
	private JPanel trackPanel;
	private JPanel east;
	private JScrollPane west;
	private JTree modelHierarchy;
	private ModelWizardView parent;
	private ComponentTrackingConfigurationPageController controller;
	private HashMap<FModel, ComponentTrackingOptionsView> trackingOptions;

	public ComponentTrackingConfigurationPageView(ModelWizardView parent)
	{
		super("second", "Component Tracking");
		this.parent = parent;
		createController();
		
		this.trackingOptions = new HashMap<FModel, ComponentTrackingOptionsView>();

		setLayout(new BorderLayout());
		setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

		trackPanel = new JPanel(new FlowLayout());
		trackPanel.setOpaque(false);
		
		east = new JPanel(new BorderLayout());
		parent.getParentView().loadModelAction();
		
		DefaultMutableTreeNode root = parent.getParentView().modelView.getModelHierarchy();

		modelHierarchy = new JTree(root);
		modelHierarchy.setCellRenderer(new ModelHierarchyRenderer(this));

		if (modelHierarchy != null)
		{
			modelHierarchy.addTreeSelectionListener(controller.onNodeSelected);
		}

		west = new JScrollPane(modelHierarchy);

		if (root != null)
		{
			FModel model = (FModel) root.getUserObject();
			createTrackingOptionsPages(root);
		}
		
		JSplitPane trackSplitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, west, east);
		trackSplitPane.setDividerLocation(150);
		trackSplitPane.setOneTouchExpandable(true);
		
		trackPanel.add(trackSplitPane, java.awt.BorderLayout.CENTER);
		
		add(trackSplitPane, BorderLayout.CENTER);
	}
	
	public void createController()
	{
		this.controller = new ComponentTrackingConfigurationPageController(this);
	}
	
	public ComponentTrackingConfigurationPageController getController()
	{
		return this.controller;
	}
	
	public ComponentTrackingConfigurationPageModel getModel()
	{
		return getController().getModel();
	}
	
	private void createTrackingOptionsPages(DefaultMutableTreeNode node)
	{
		FModel model = (FModel) node.getUserObject();
		trackingOptions.put(model, new ComponentTrackingOptionsView(this, getTrackerFor(model), model));

		Enumeration<TreeNode> children = node.children();
		while(children.hasMoreElements())
		{
			createTrackingOptionsPages((DefaultMutableTreeNode) children.nextElement());
		}
	}
	
	public Tracker getTrackerFor(FModel model)
	{
		return getParentView().getParentView().modelView.getTrackingControl().findTrackerFor(model);
	}

	public void setEast(FModel model)
	{
		this.east.removeAll();
		this.east.add(Box.createRigidArea(new Dimension(150, 1)));
		this.east.add(this.trackingOptions.get(model));
		this.east.revalidate();
		this.east.repaint();
	}
	
	public JPanel getEast()
	{
		return this.east;
	}

	@Override
	public void rendering(List<WizardPage> path, WizardSettings settings)
	{
		this.setFinishEnabled();
		this.setNextDisabled();
	}

	public void setFinishEnabled()
	{
		super.setFinishEnabled(true);
	}

	public void setFinishDisabled()
	{
		super.setFinishEnabled(false);
	}

	public void setNextEnabled()
	{
		super.setNextEnabled(true);
	}

	public void setNextDisabled()
	{
		super.setNextEnabled(false);
	}

	public JTree getModelHierarchy()
	{
		return this.modelHierarchy;
	}

	public ModelWizardView getParentView()
	{
		return this.parent;
	}
}
