/* 
 * Author     : ACIMS(Arizona Centre for Integrative Modeling & Simulation)
 *  Version    : DEVSJAVA 2.7 
 *  Date       : 08-15-02 
 */
package view;

/**
 * Facade Connections
 * Tracker: tracks data from the facade layer
 */
import facade.modeling.*;
import view.timeView.Event;
import view.timeView.Graph;

import java.util.List;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ArrayList;

public class Tracker
{
	private boolean isTimeViewSelected;
	private boolean istrackinglogselected; // to make one tracking log panel

	private boolean isBreakout = false;

	private int modelNum;
	private Event e;
	private double time;
	private boolean atLeastOneInputTracked;
	private boolean atLeastOneOutputTracked;
	private boolean[] trackInputPorts_stack;
	private boolean[] trackInputPorts_sep;
	private boolean[] trackOutputPorts_sep;
	private boolean[] trackOutputPorts_stack;
	private boolean[] trackState_sep;
	private boolean[] trackState_stack;
	private boolean[] trackTime_sep;
	private boolean[] trackTime_stack;
	private List<Object> timeViewData;
	private List<Object>[] dataStorage;
	private String[] dataHeaderList;
	private boolean isAtomic;
	private TrackingControl trackingControl;
	private FModel model;
	private String xUnit = "sec";
	private String timeIncr = "10";

	private ArrayList<Graph> graphs;
	private String[] inputPortUnits;
	private String[] outputPortUnits;
	private String[] stateUnits;
	private String[] timeUnits;

	public Tracker(FModel model, int num)
	{
		this.model = model;
		modelNum = num; // model number for this tracker
		atLeastOneInputTracked = false;
		atLeastOneOutputTracked = false;
		trackInputPorts_stack = makeBooleanArray(model.getInputPortNames().size(), false);
		trackOutputPorts_stack = makeBooleanArray(model.getOutputPortNames().size(), false);
		trackInputPorts_sep = makeBooleanArray(model.getInputPortNames().size(), false);
		trackOutputPorts_sep = makeBooleanArray(model.getOutputPortNames().size(), false);
		trackState_sep = makeBooleanArray(model.getStateNames().size(), false);
		trackState_stack = makeBooleanArray(model.getStateNames().size(), false);
		trackTime_sep = makeBooleanArray(model.getTimeDimensionNames().size(), false);
		trackTime_stack = makeBooleanArray(model.getTimeDimensionNames().size(), false);
		
		graphs = new ArrayList<Graph>();

		inputPortUnits = makeEmptyStringArray(model.getInputPortNames().size());
		outputPortUnits = makeEmptyStringArray(model.getOutputPortNames().size());
		stateUnits = makeEmptyStringArray(model.getStateNames().size());
		timeUnits = makeEmptyStringArray(model.getTimeDimensionNames().size());
		
		isTimeViewSelected = false;
		istrackinglogselected = false;

		isAtomic = model instanceof FAtomicModel;

		trackingControl = new TrackingControl();

		ArrayList<Object> dataStore = new ArrayList<Object>(10);
		ArrayList<Object> dataHeader = new ArrayList<Object>(10);
		
	    initializeDataStore(model.getStateNames(), dataHeader, dataStore);
	    initializeDataStore(model.getTimeDimensionNames(), dataHeader, dataStore);
	    initializeDataStore(model.getInputPortNames(), dataHeader, dataStore);
	    initializeDataStore(model.getOutputPortNames(), dataHeader, dataStore);

		dataStorage = (List<Object>[]) dataStore.toArray(new LinkedList<?>[0]);
		dataHeaderList = (String[]) dataHeader.toArray(new String[0]);
	}
	
	private String[] makeEmptyStringArray(int size)
	{
	    String[] newArray = new String[size];
	    for(int i = 0; i < size; ++i)
	    {
	        newArray[i] = "";
	    }
	    
	    return newArray;
	}
	
	private boolean[] makeBooleanArray(int size, boolean value)
	{
	    boolean[] newArray = new boolean[size];
	    for(int i = 0; i < size; ++i)
	    {
	        newArray[i] = value;
	    }
	    
	    return newArray;
	}
	
	private void initializeDataStore(List<String> entityNames, 
	        ArrayList<Object> dataHeader, 
	        ArrayList<Object> dataStore)
	{
	    for (String name : entityNames)
	    {
	        dataHeader.add(name);
	        dataStore.add(new LinkedList<Object>());
	    }
	}

	public String toString()
	{
		return model.getName();
	}

	public FModel getAttachedModel()
	{
		return model;
	}

	public List[] getDataStorage()
	{
		return dataStorage;
	}

	public String[] getDataHeaders()
	{
		return dataHeaderList;
	}

	public void saveCurrentTrackingState(double currentTime)
	{
		// time = currentTime;
		int offset = 4;
		if (isAtomic)
		{
			FAtomicModel atomic = (FAtomicModel) model;
			dataStorage[0].add((getTrackPhaseStack() || getTrackPhaseSeparate()) ? atomic.getPhase() : null);
			dataStorage[1].add((getTrackSigmaStack() || getTrackSigmaSeparate()) ? "" + atomic.getSigma() : null);

		} else
		{
			dataStorage[0].add(null);
			dataStorage[1].add(null);
		}
		dataStorage[2].add((getTrackTLStack() || getTrackTLSeparate()) ? "" + model.getTimeOfLastEvent() : null);
		dataStorage[3].add((getTrackTNStack() || getTrackTNSeparate()) ? "" + model.getTimeOfNextEvent() : null);

		List inputPorts = model.getInputPortNames();
		for (int i = 0; i < inputPorts.size(); i++)
		{
			if (trackInputPorts_stack[i] || trackInputPorts_sep[i])
			{
				String tmp = "";
				Iterator it = model.getInputPortContents((String) inputPorts.get(i)).iterator();
				while (it.hasNext())
					tmp += "{" + it.next() + "} ";
				dataStorage[offset++].add((tmp.length() == 0) ? null : tmp);
			} else
				dataStorage[offset++].add(null);
		}

		List outputPorts = model.getOutputPortNames();
		for (int i = 0; i < outputPorts.size(); i++)
		{
			if (trackOutputPorts_stack[i] || trackOutputPorts_sep[i])
			{
				String tmp = "";
				Iterator it = model.getOutputPortContents((String) outputPorts.get(i)).iterator();
				while (it.hasNext())
					tmp += "{" + it.next() + "} ";
				dataStorage[offset++].add((tmp.length() == 0) ? null : tmp);
			} else
				dataStorage[offset++].add(null);
		}
	}

	public String getCurrentTrackingHTMLString()
	{
		String html = "";
		if (isAtomic)
		{
			FAtomicModel atomic = (FAtomicModel) model;
			if (getTrackPhaseStack() || getTrackPhaseSeparate())
				html += "<B>Phase:</B> " + atomic.getPhase() + "<BR>";

			if (getTrackSigmaStack() || getTrackSigmaSeparate())
				html += "<B>Sigma:</B> " + atomic.getSigma() + "<BR>";
		}

		if (getTrackTLStack() || getTrackTLSeparate())
			html += "<B>TL:</B> " + model.getTimeOfLastEvent() + "<BR>";

		if (getTrackTNStack() || getTrackTNSeparate())
			html += "<B>TN:</B> " + model.getTimeOfNextEvent() + "<BR>";
		if (atLeastOneInputTracked)
		{
			html += "<B>Input Ports:</B><BR> ";
			List inputPorts = model.getInputPortNames();
			for (int i = 0; i < inputPorts.size(); i++)
			{
				if (trackInputPorts_stack[i] || trackInputPorts_sep[i])
				{
					html += inputPorts.get(i) + ": ";
					Iterator it = model.getInputPortContents((String) inputPorts.get(i)).iterator();
					while (it.hasNext())
						html += "{" + it.next() + "} ";
					html += "<BR>";
				}
			}
		}
		if (atLeastOneOutputTracked)
		{
			html += "<B>Output Ports:</B> <BR>";
			List outputPorts = model.getOutputPortNames();
			for (int i = 0; i < outputPorts.size(); i++)
			{
				if (trackOutputPorts_stack[i] || trackOutputPorts_sep[i])
				{
					html += outputPorts.get(i) + ": ";
					Iterator it = model.getOutputPortContents((String) outputPorts.get(i)).iterator();
					while (it.hasNext())
						html += "{" + it.next() + "} ";
					html += "<BR>";
				}
			}
		}

		return html;
	}

	public List getCurrentTimeViewData(double currentTime)
	{
		timeViewData = new ArrayList(1);
		time = currentTime;
		if (isAtomic)
		{
			FAtomicModel atomic = (FAtomicModel) model;
			if (getTrackPhaseStack() || getTrackPhaseSeparate())
			{
				e = new Event("Phase", "STATE", time, atomic.getPhase());
				timeViewData.add(e);
			}
			if (getTrackSigmaStack() || getTrackSigmaSeparate())
			{
				e = new Event("Sigma", "SIGMA", time, String.valueOf(atomic.getSigma()));
				timeViewData.add(e);
			}
		}

		if (getTrackTLStack() || getTrackTLSeparate())
		{
			e = new Event("tL", "STATEVARIABLE", time, String.valueOf(model.getTimeOfLastEvent()));
			timeViewData.add(e);
		}

		if (getTrackTNStack() || getTrackTNSeparate())
		{

			e = new Event("tN", "STATEVARIABLE", time, String.valueOf(model.getTimeOfNextEvent()));
			timeViewData.add(e);
		}

		if (atLeastOneInputTracked)
		{
			List inputPorts = model.getInputPortNames();
			for (int i = 0; i < inputPorts.size(); i++)
			{
				if (trackInputPorts_stack[i] || trackInputPorts_sep[i])
				{
					Iterator it = model.getInputPortContents((String) inputPorts.get(i)).iterator();
					if (it.hasNext())
					{
						e = new Event(inputPorts.get(i).toString(), "INPUT", time, it.next());
						timeViewData.add(e);
					}
				}
			}
		}

		if (atLeastOneOutputTracked)
		{

			List outputPorts = model.getOutputPortNames();
			for (int i = 0; i < outputPorts.size(); i++)
			{
				if (trackOutputPorts_stack[i] || trackOutputPorts_sep[i])
				{
					Iterator it = model.getOutputPortContents((String) outputPorts.get(i)).iterator();

					if (it.hasNext())
					{

						// change to object
						e = new Event(outputPorts.get(i).toString(), "OUTPUT", time, it.next());
						timeViewData.add(e);
					}
				}
			}
		}

		return timeViewData;
	}

	public boolean isTrackingSelected()
	{
		return istrackinglogselected;
	}

	public boolean isTimeViewSelected()
	{
		return isTimeViewSelected;
	}
	
	public boolean[] getTrackStateStack()
	{
	    return this.trackState_stack;
	}

	public boolean[] getTrackStateSeparate()
	{
	    return this.trackState_sep;
	}
	
	public boolean[] getTrackTimeDimensionStack()
	{
	    return this.trackTime_stack;
	}
	
	public boolean[] getTrackTimeDimensionSeparate()
	{
	    return this.trackTime_sep;
	}
	
	public void setTrackTLStack(boolean set)
	{
		getTrackTimeDimensionStack()[0] = set;
	}

	public boolean getTrackTLStack()
	{
		return getTrackTimeDimensionStack()[0];
	}

	public boolean getTrackTNStack()
	{
		return getTrackTimeDimensionStack()[1];
	}

	public void setTrackTNStack(boolean set)
	{
	    getTrackTimeDimensionStack()[1] = set;
	}

	public boolean getTrackPhaseSeparate()
	{
		return getTrackStateSeparate()[0];
	}

	public void setTrackPhaseSeparate(boolean set)
	{
		getTrackStateSeparate()[0] = set;
	}
	
	public boolean getTrackPhaseStack()
	{
	    return getTrackStateStack()[0];
	}

	public void setTrackPhaseStack(boolean set)
	{
	    getTrackStateStack()[0] = set;
	}
	
    public boolean getTrackSigmaStack()
    {
        return getTrackStateStack()[1];
    }

    public void setTrackSigmaStack(boolean set)
    {
        getTrackStateStack()[1] = set;
    }

	public boolean getTrackSigmaSeparate()
	{
		return getTrackStateSeparate()[1];
	}

	public void setTrackSigmaSeparate(boolean set)
	{
		getTrackStateSeparate()[1] = set;
	}

	public void setTrackTLSeparate(boolean set)
	{
		getTrackTimeDimensionSeparate()[0] = set;
	}

	public boolean getTrackTLSeparate()
	{
		return getTrackTimeDimensionSeparate()[0];
	}

	public boolean getTrackTNSeparate()
	{
		return getTrackTimeDimensionSeparate()[1];
	}

	public void setTrackTNSeparate(boolean set)
	{
	    getTrackTimeDimensionSeparate()[1] = set;
	}

	public void setTimeViewSelected(boolean set)
	{
		isTimeViewSelected = set;
	}

	public boolean getTimeViewSelected()
	{
		return isTimeViewSelected;
	}

	public void setTrackingLogSelected(boolean set)
	{
		istrackinglogselected = set;
	}

	public boolean getTrackingLogSelected()
	{
		return istrackinglogselected;
	}

	public TrackingControl getTrackingControl()
	{
		return trackingControl;
	}

	public int getModelNum()
	{
		return modelNum;
	}

	public boolean[] gettrackInputPortsStack()
	{
		return trackInputPorts_stack;
	}

	public void settrackInputPortsStack(boolean[] trackInputPorts)
	{
		this.trackInputPorts_stack = trackInputPorts;
	}

	public boolean[] gettrackInputPortsSeparate()
	{
		return trackInputPorts_sep;
	}

	public void settrackInputPortsSeparate(boolean[] trackInputPorts)
	{
		this.trackInputPorts_sep = trackInputPorts;
	}

	public boolean[] gettrackOutputPortsSeparate()
	{
		return trackOutputPorts_sep;
	}

	public void settrackOutputPortsSeparate(boolean[] trackOutputPorts)
	{
		this.trackOutputPorts_sep = trackOutputPorts;
	}

	public boolean[] gettrackOutputPortsStack()
	{
		return trackOutputPorts_stack;
	}

	public void settrackOutputPortsStack(boolean[] trackOutputPorts)
	{
		this.trackOutputPorts_stack = trackOutputPorts;
	}

	public void setGraphs(ArrayList<Graph> graphs)
	{
		this.graphs = graphs;
	}

	public ArrayList<Graph> getGraphs()
	{
		return graphs;
	}

	public String getxUnit()
	{
		return xUnit;
	}

	public void setxUnit(String unit)
	{
		xUnit = unit;
	}

	public String gettimeIncrement()
	{
		return timeIncr;
	}

	public void settimeIncrement(String tInc)
	{
		timeIncr = tInc;
	}

	public void setisBreakout(boolean set)
	{
		isBreakout = set;
	}

	public boolean getisBreakout()
	{
		return isBreakout;
	}

	public String[] getInputPortUnits()
	{
		return inputPortUnits;
	}

	public void setInputPortUnits(String[] units)
	{
		inputPortUnits = units;
	}

	public String[] getOutputPortUnits()
	{
		return outputPortUnits;
	}
	
	public String[] getStateUnits()
	{
	    return stateUnits;
	}
	
	public String[] getTimeUnits()
	{
	    return timeUnits;
	}

	public void setOutputPortUnits(String[] units)
	{
		outputPortUnits = units;
	}

	public void setatLeastOneInputTracked(boolean set)
	{
		atLeastOneInputTracked = set;
	}

	public boolean getatLeastOneInputTracked(boolean set)
	{
		return atLeastOneInputTracked;
	}

	public void setatLeastOneOutputTracked(boolean set)
	{
		atLeastOneOutputTracked = set;
	}

	public boolean getatLeastOneOutputTracked(boolean set)
	{
		return atLeastOneOutputTracked;
	}

}