package view.modelwizard.m;

public class InitialConfigurationPageModel
{
	public FileSystemConfigurationModel fileSystemConfiguration;
	public InitialConfigurationCheckboxOptionsModel checkboxOptions;
}
