package view.modelwizard.m;

import java.util.ArrayList;
import javax.swing.tree.DefaultMutableTreeNode;

import facade.modeling.FModel;
import view.modeling.ViewableDigraph;
import view.modelwizard.v.ComponentTrackingConfigurationPageView;

public class ComponentTrackingConfigurationPageModel
{
	private ComponentTrackingConfigurationPageView view;
	private ArrayList<DefaultMutableTreeNode> trackedNodes;
	private ViewableDigraph devsModel;
	private short modelType;
	
	public ComponentTrackingConfigurationPageModel(ComponentTrackingConfigurationPageView view)
	{
		this.view = view;
		
		view.getParentView().getModel().setComponentTrackingConfigModel(this);
		this.trackedNodes = new ArrayList<DefaultMutableTreeNode>();
	}
	
	public void setDEVSModel(ViewableDigraph model)
	{
		this.devsModel = model;
	}
	
	public void setModelType(short modelType)
	{
		this.modelType = modelType;
	}
	
	public ViewableDigraph getDEVSModel()
	{
		return this.devsModel;
	}
	
	public short getModelType()
	{
		return this.modelType;
	}
	
	public ArrayList<DefaultMutableTreeNode> getTrackedNodes()
	{
		return this.trackedNodes;
	}
	
	public void addTrackedNode(DefaultMutableTreeNode node)
	{
		this.trackedNodes.add(node);
	}
	
	public void clearTrackedNodes()
	{
		this.trackedNodes.clear();
	}
	
	public boolean trackedNodesContains(DefaultMutableTreeNode node)
	{
		return this.trackedNodes.contains(node);
	}
	
	public boolean trackedNodesContains(FModel model)
	{
		for(DefaultMutableTreeNode node : this.trackedNodes)
		{
			if((FModel) node.getUserObject() == model)
			{
				return true;
			}
		}
		return false;
	}
}
