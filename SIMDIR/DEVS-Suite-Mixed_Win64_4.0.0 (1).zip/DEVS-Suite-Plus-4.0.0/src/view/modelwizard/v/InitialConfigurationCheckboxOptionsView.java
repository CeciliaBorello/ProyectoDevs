package view.modelwizard.v;

import java.awt.GridLayout;

import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.SwingConstants;

import view.View;
import view.modelwizard.c.InitialConfigurationCheckboxOptionsController;
import view.modelwizard.m.InitialConfigurationCheckboxOptionsModel;

public class InitialConfigurationCheckboxOptionsView extends JPanel
{
	private static final long serialVersionUID = -7839915800185030099L;
	private JCheckBox isSimViewSelected, isTrackingSelected;
	private JRadioButton NonCAButton, CAButton;
	private InitialConfigurationCheckboxOptionsController controller;
	private final GridLayout CHECKBOX_LAYOUT = new GridLayout(2, 1);
	private final GridLayout RADIO_BUTTON_LAYOUT = new GridLayout(1, 1);
	private InitialConfigurationPageView parent;
	
	public InitialConfigurationCheckboxOptionsView(InitialConfigurationPageView parent)
	{
		this.parent = parent;
		this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		createController();
		
		JPanel radioButtonPanel = new JPanel(RADIO_BUTTON_LAYOUT);
		
		NonCAButton = new JRadioButton("Component Model");
		NonCAButton.setActionCommand("Component Model");
		NonCAButton.setSelected(true);

		CAButton = new JRadioButton("CA Model");
		CAButton.setActionCommand("CA Model");
		CAButton.addItemListener(this.getController().onCAButtonPressed);

		ButtonGroup group = new ButtonGroup();
		group.add(NonCAButton);
		group.add(CAButton);

		NonCAButton.setHorizontalAlignment(SwingConstants.LEFT);

		radioButtonPanel.add(NonCAButton);
		radioButtonPanel.add(CAButton);
		
		this.add(radioButtonPanel);
		
		JPanel checkboxPanel = new JPanel(CHECKBOX_LAYOUT);
		
		isSimViewSelected = new JCheckBox("SimView");
        isSimViewSelected.setHorizontalAlignment(SwingConstants.LEFT);
        isSimViewSelected.addItemListener(this.getController().onSimViewSelected);
       
        checkboxPanel.add(isSimViewSelected);
        
        isTrackingSelected = new JCheckBox("Tracking");
        isTrackingSelected.setHorizontalAlignment(SwingConstants.LEFT);
        isTrackingSelected.addItemListener(this.getController().onTrackingSelected);
        
        checkboxPanel.add(isTrackingSelected);

        this.add(checkboxPanel);
        
        this.getController().refreshOptions();
	}
	
	public void setCAOptions()
	{
        CAButton.setSelected(true);
        isSimViewSelected.setEnabled(false);
        isSimViewSelected.setSelected(false);
        isTrackingSelected.setEnabled(false);
        isTrackingSelected.setSelected(false);
	}
	
	public void setNonCAOptions()
	{
		NonCAButton.setSelected(true);
		isSimViewSelected.setEnabled(true);
		isTrackingSelected.setEnabled(true);
	}
	
	public boolean isConfiguredForCAModel()
	{
		return View.isCAModel;
	}
	
	public boolean isCAModel()
	{
		return this.getModel().isCAModel();
	}
	
	public void createController()
	{
		this.controller = new InitialConfigurationCheckboxOptionsController(this);
	}
	
	public InitialConfigurationPageView getParentView()
	{
		return this.parent;
	}
	
	public InitialConfigurationCheckboxOptionsController getController()
	{
		return this.controller;
	}
	
	public InitialConfigurationCheckboxOptionsModel getModel()
	{
		return this.getController().getModel();
	}
}
