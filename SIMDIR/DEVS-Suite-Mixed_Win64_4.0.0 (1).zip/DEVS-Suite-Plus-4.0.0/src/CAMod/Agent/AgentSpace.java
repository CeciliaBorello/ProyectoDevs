package CAMod.Agent;

import java.util.Random;

import model.modeling.CAModels.TwoDimCellSpace;

public class AgentSpace extends TwoDimCellSpace {

	private final String[] statusCXCL12 = { "EMPTY", "EMPTY", "EMPTY", "CXCL12" };
	private final String[] statusCXCLR4 = { "EMPTY", "EMPTY", "EMPTY", "CXCR4" };
	private final String[] statusCXCLR7 = { "EMPTY", "EMPTY", "EMPTY", "CXCR7" };

	public AgentSpace() {
		this(40, 40);
	}

	public AgentSpace(int xDim, int yDim) {
		super("Chemotaxis", xDim, yDim);

		this.numCells = xDim * yDim;
		for (int i = 0; i < xDimCellspace; i++) {
			for (int j = 0; j < yDimCellspace; j++) {
				Random randomno = new Random();
				Agent cell;
				if (i <= xDimCellspace / 3) {
					cell = new Agent(i, j, statusCXCL12[randomno.nextInt(statusCXCL12.length)], 1);
				} else if (i >= xDimCellspace / 3 * 2) {
					cell = new Agent(i, j, statusCXCLR4[randomno.nextInt(statusCXCLR4.length)], 1);
				} else {
					cell = new Agent(i, j, statusCXCLR7[randomno.nextInt(statusCXCLR7.length)], 1);
				}
				addCell(cell);
				cell.initialize();
			}
		}

		doNeighborToNeighborCoupling();

	}
}
