package view.modelwizard.c;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import view.Tracker;
import view.modelwizard.v.TrackingStyleView;

public class TrackingStyleController
{
	private TrackingStyleView view;

	public TrackingStyleController(TrackingStyleView view)
	{
		this.view = view;
	}
	
	public Tracker getTracker()
	{
		return this.view.getParentView().getModel().getTracker();
	}
	
	public ItemListener onTimeViewChanged = new ItemListener() {
		public void itemStateChanged(ItemEvent e)
		{
			if (e.getStateChange() == ItemEvent.SELECTED)
			{
				getTracker().setisBreakout(false);
				view.enableTrackButton();
			} else
			{
				if (view.isTimeViewSeparatedSelected() || view.isHTMLTrackingSelected())
				{
					view.enableTrackButton();
				} 
				else
				{
					view.disableTrackButton();
				}
			}
		}
	};
	
	public ItemListener onTimeViewSeparatedChanged = new ItemListener() {
		public void itemStateChanged(ItemEvent e)
		{
			if (e.getStateChange() == ItemEvent.SELECTED)
			{
				getTracker().setisBreakout(true);
				view.enableTrackButton();
			} else
			{
				if (view.isTimeViewSelected() || view.isHTMLTrackingSelected())
				{
					view.enableTrackButton();
				}
				else
				{
					view.disableTrackButton();
				}
			}
		}
	};
	
	public ItemListener onHTMLTrackingChanged = new ItemListener() {
		public void itemStateChanged(ItemEvent e)
		{
			if (e.getStateChange() == ItemEvent.SELECTED)
			{
				view.enableTrackButton();
			} 
			else
			{
				if (view.isTimeViewSelected() || view.isTimeViewSeparatedSelected())
				{
					view.enableTrackButton();
				} 
				else
				{
					view.disableTrackButton();
				}
			}
		}
	};
}
