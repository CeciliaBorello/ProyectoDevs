package view.modelheirarchy.v;

import java.util.Iterator;

import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeSelectionModel;

import facade.modeling.FAtomicModel;
import facade.modeling.FCoupledModel;
import facade.modeling.FModel;
import view.FModelView;
import view.modelheirarchy.c.ModelHierarchyController;

public class ModelHierarchyView extends JTree
{
	private DefaultMutableTreeNode root;
	private ModelHierarchyController controller;
	
	public ModelHierarchyView(FModelView parent, FModel rootModel)
	{
		createController(parent);
		
        if (rootModel instanceof FAtomicModel)
        {
        	root = new DefaultMutableTreeNode(rootModel,false);
        }
        else if (rootModel instanceof FCoupledModel)
        {
        	root = createCoupledNode((FCoupledModel)rootModel);
        }
        
        DefaultTreeModel treeModel = (DefaultTreeModel) super.getModel();
        treeModel.setRoot(root);

        super.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
        super.addTreeSelectionListener(controller.onSelectionChanged);
	}
	
	public void createController(FModelView parent)
	{
		this.controller = new ModelHierarchyController(this, parent);
	}
	
	public ModelHierarchyController getController()
	{
		return this.controller;
	}
	
	public Object getLastSelectedObject()
	{
		DefaultMutableTreeNode node = (DefaultMutableTreeNode) super.getLastSelectedPathComponent();
		if(node != null)
		{
			return node.getUserObject();
		}
		return null;
	}
	
    private DefaultMutableTreeNode createCoupledNode(FCoupledModel model)
    {
        DefaultMutableTreeNode node = new DefaultMutableTreeNode(model,true);
        Iterator children = model.getChildren().iterator();
        while (children.hasNext())
        {
            FModel next = (FModel)children.next();
            if (next instanceof FAtomicModel)
            {
            	node.add(new DefaultMutableTreeNode(next,false));
            }
            else if (next instanceof FCoupledModel)
            {
            	node.add(createCoupledNode((FCoupledModel) next));
            }
        }
        return node;
    }
    
    public DefaultMutableTreeNode getRoot()
    {
    	return this.root;
    }
}
