package view.modelheirarchy.c;

import java.awt.event.ActionEvent;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;

import facade.modeling.FModel;
import view.FModelView;
import view.modelheirarchy.v.ModelHierarchyView;

public class ModelHierarchyController
{
	private ModelHierarchyView view;
	private FModelView parent;

	public ModelHierarchyController(ModelHierarchyView view, FModelView parent)
	{
		this.view = view;
		this.parent = parent;
	}
	
	public TreeSelectionListener onSelectionChanged = new TreeSelectionListener() {
		public void valueChanged(TreeSelectionEvent e)
		{
			selectionChanged();
		}

		public void actionPerformed(ActionEvent e)
		{
			actionPerformed(e);
		}
	};
	
	public void selectionChanged()
	{
		DefaultMutableTreeNode node = (DefaultMutableTreeNode) view.getLastSelectedPathComponent();
		if (node != null)
		{
			parent.setDetails((FModel) node.getUserObject());
		}
	}
	
	public void actionPerformed(ActionEvent e)
	{
		DefaultMutableTreeNode node = (DefaultMutableTreeNode) view.getLastSelectedPathComponent();
		if (node != null)
		{
			String actionCmd = e.getActionCommand();
			if (actionCmd.equalsIgnoreCase("INJECT"))
			{
				parent.showInjectInput((FModel) node.getUserObject());
			}
		}
	}
}
