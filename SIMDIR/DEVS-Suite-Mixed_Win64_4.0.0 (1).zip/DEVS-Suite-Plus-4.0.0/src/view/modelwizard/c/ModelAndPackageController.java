package view.modelwizard.c;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.StringReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.TreeSet;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.swing.JComboBox;
import javax.swing.JOptionPane;

import view.View;
import view.modelwizard.m.ModelAndPackageModel;
import view.modelwizard.v.InitialConfigurationPageView;
import view.modelwizard.v.ModelAndPackageView;

public class ModelAndPackageController
{
	private ModelAndPackageView view;
	private ModelAndPackageModel model;
	
	public ModelAndPackageController(ModelAndPackageView view)
	{
		this.view = view;
		this.model = new ModelAndPackageModel();
	}
	
	public ModelAndPackageView getView()
	{
		return this.view;
	}
	
	public ModelAndPackageModel getModel()
	{
		return this.model;
	}
	
	public void update(String packagesAreaText, String lastSelectedPackage, String lastSelectedModel)
	{
		this.model.clearPackagesList();
		createPackagesList(packagesAreaText);
		
		view.populatePackagesBox();
		
		if(lastSelectedPackage != null)
		{
			view.setSelectedPackage(lastSelectedPackage);
		}
		
		if(view.getPackagesBox().getSelectedIndex() > 0)
		{
			view.populateModelsBox();
			
			if(lastSelectedModel != null)
			{
				view.setSelectedModel(lastSelectedModel);
			}
		}
		else
		{
			view.getModelsBox().removeAllItems();
		}
	}
	
	private void createPackagesList(String packagesAreaText)
	{
		StringReader stringReader = new StringReader(packagesAreaText);
        BufferedReader reader = new BufferedReader(stringReader);
        
        while (true) 
        {
            // read the next line specified in the packages text area
        	String line = null;
            try 
            {
                line = reader.readLine();
            } 
            catch (IOException ex) 
            {
            	ex.printStackTrace(); 
            	continue;
        	}

            // if there are no more lines
            if (line == null) 
            {
            	break;
            }

            // if this line is blank, skip it
            if (line.trim().equals(""))
            {
            	continue;
            }

            this.model.addPackage(line);
        }
	}
	
	public void createModelsList()
	{
    	this.model.clearModelsList();
    	
        // create a filename filter (to be used below) that will
        // match against ".class" files (and ignore inner classes)
    	TreeSet sortedFiles=null;
        final String extension = ".class";
        FilenameFilter filter =  new FilenameFilter() {
            public boolean accept(File dir, String name) {
                return name.endsWith(extension) && name.indexOf('$') == -1;
            }
        };
        
        // find all java class files (that aren't inner classes) in the
        // models-path
        String classPath = view.getParentView().getModel().fileSystemConfiguration.getClassPath();
        if(classPath.matches("(.*).jar(.*)"))
        {
        	try {
				URL jar;
				String name;
				ArrayList classes = new ArrayList();
				File path = new File(classPath);
				jar = path.toURI().toURL();
				ZipInputStream zip = new ZipInputStream( jar.openStream());
			
				while(true) 
				{
					ZipEntry entry = zip.getNextEntry();
					if (entry == null)
					{
						break;
					}
					name= entry.getName();
			   
					//for onejar
					if(name.startsWith("main")&& name.endsWith("main.jar"))
					{
						ZipInputStream innerZip = new ZipInputStream(zip);
						String innerName=null;
						while(true)
						{
							ZipEntry innerEntry = innerZip.getNextEntry();
							if(innerEntry==null)
							{
								break;
							}
            		   
							innerName= innerEntry.getName();
            		   
							if (innerName.startsWith(View.curPackages) 
									&& innerName.endsWith (".class"))
					    	{
								String names[]= null;
					    	    if(innerName.matches("(.*)/(.*)"))
					    	    {
					    	    	names = innerName.split("/");
					    	    }
					    	    else
					    	    {
					    	    	names = innerName.split("\\");
					    	    }
				                classes.add(names[names.length-1]);
					    	}
						}
					}
					if (name.startsWith(View.curPackages)
			    		&& name.endsWith (".class"))
					{
						String names[]= null;
						if(name.matches("(.*)/(.*)"))
						{
							names = name.split("/");
						}
						else
						{
							names = name.split("\\");
						}
						classes.add(names[names.length-1]);
					}  
				}
				if (classes.isEmpty())
				{
		            JOptionPane.showMessageDialog(view,
		                "The selected models package does not appear to be available for loading.  " +
		                "Please select another.");
		        }
				sortedFiles = new TreeSet(classes);
        	} 
        	catch (MalformedURLException e1) {
        		e1.printStackTrace();
        	}
        	catch (IOException e) {
        		e.printStackTrace();
        	}
        }
        else
        {
	        File path = new File(classPath 
	        		           + "/" 
	        		           + View.curPackages.replace('.', '/'));
	        File[] files = path.listFiles(filter);
	        
	        // if the models-path doesn't exist
	        if (files == null) {
	        	JOptionPane.showMessageDialog(view,
	        			"The selected models package does not appear to be available for loading.  " +
	        			"Please select another.");
	        }
        
	        // sort the names of the java class files found above
	        sortedFiles = new TreeSet(Arrays.asList(files));
        }
        
        this.model.addModel("Select a model");

        // for each java class file in the models-path (we are assuming
        // each such file to be a compiled devs java model)
        Iterator i = sortedFiles.iterator();
        while (i.hasNext())
        {
            // add this class file's name (minus its extension) to the box
        	Object temp = i.next();
        	String name = null;
        	if(temp instanceof File)
        	{
        		name = ((File)temp).getName();
        	}
        	else
        	{
        		name = ((String)temp);
        	}
        	this.model.addModel(name.substring(0, name.length() - extension.length()));
        }
	}
	
	public ActionListener onPackagesBoxChange = new ActionListener() {
        public void actionPerformed(ActionEvent e) {
        	JComboBox<String> packagesBox = view.getPackagesBox();
            // ignore the first choice when it is selected, as it is
            // just an instructions string; also, ignore when no choice
            // is selected
            if (packagesBox.getSelectedIndex() <= 0) 
            {
            	return;
            }
            // make the selected item the current model package name
            View.curPackages = (String)packagesBox.getSelectedItem();           	
            
            createModelsList();
            view.populateModelsBox();
        }
    };
	
	public ActionListener onModelsBoxChange = new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent e)
		{
			JComboBox<String> modelsBox = view.getModelsBox();
            // ignore the first choice when it is selected, as it is
            // just an instructions string; also, ignore when no choice
            // is selected
            if (modelsBox.getSelectedIndex() <= 0)
            {
            	return;
            }
            
            view.getParentView().getCheckboxOptions().getController().refreshButtons();
            view.getParentView().getParentView().modelName = (String) modelsBox.getSelectedItem();
            view.getParentView().getParentView().setLastModelViewed(view.getParentView().getParentView().modelName);
		}
	};

}
