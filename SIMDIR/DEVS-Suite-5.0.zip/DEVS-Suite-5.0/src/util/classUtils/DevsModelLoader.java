package util.classUtils;

import java.util.List;
import java.util.Optional;

import controller.ControllerInterface;
import facade.modeling.FModel;
import view.ViewInterface;
import view.modeling.ViewableAtomic;
import view.modeling.ViewableDigraph;

public class DevsModelLoader
{
    public static LoadedDevsModel loadModelClass(String selectedPkg, String selectedModel)
    {
        LoadedDevsModel data = new LoadedDevsModel();
        
        if (selectedPkg != null && selectedModel != null)
        {
            try
            {
                Object instance;
                Class<?> modelClass;
                try
                {
                    modelClass = DevsClassFileReader.readClass(selectedPkg, selectedModel);
                    instance = modelClass.getConstructor().newInstance();
                }
                catch (Exception en)
                {
                    en.printStackTrace();
                    return data;
                }

                if (instance instanceof ViewableAtomic)
                {
                    data.instanceModel = new ViewableDigraph("ViewableAtomic");
                    
                    ViewableAtomic atomic = (ViewableAtomic) instance;

                    data.instanceModel.add(atomic);
                    // for each of the names of the outports of the atomic
                    
                    List<?> names = atomic.getOutportNames();
                    for (int i = 0; i < names.size(); i++)
                    {
                        String portName = (String) names.get(i);

                        // add an outport with this port name to the wrapper
                        // digraph,
                        // and couple it to the atomic's outport of this name,
                        // so that outputs from that outport will be visible
                        // when they are emitted
                        data.instanceModel.addOutport(portName);
                        data.instanceModel.addCoupling(atomic, portName, data.instanceModel, portName);
                    }

                    data.modelType = FModel.ATOMIC;
                }
                else if (instance instanceof ViewableDigraph)
                {
                    data.instanceModel = (ViewableDigraph) instance;
                    data.modelType = FModel.COUPLED;
                }
            }
            catch (Exception e)
            {
                System.err.println("An Error Occured While Loading Model: " + e);
                e.printStackTrace();
            }
        }
        return data;
    }
    
    public static void initializeSimulatorWithModel(ViewInterface v, LoadedDevsModel data)
    {
        if (v.isCASelected() )
        {
            v.getController().userGesture(ControllerInterface.LOAD_MODEL_ASYNC, null);
        }
        else
        {
            v.getController().userGesture(ControllerInterface.LOAD_MODEL_GESTURE, null);
        }
                
        v.getController().initializeSimulator(data);
    }
    
    /**
     * Singleton class; no instances.
     */
    private DevsModelLoader()
    {
        
    }
}
