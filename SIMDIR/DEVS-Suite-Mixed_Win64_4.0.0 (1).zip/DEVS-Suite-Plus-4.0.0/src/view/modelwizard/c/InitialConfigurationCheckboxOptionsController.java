package view.modelwizard.c;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import view.View;
import view.modelwizard.m.InitialConfigurationCheckboxOptionsModel;
import view.modelwizard.v.InitialConfigurationCheckboxOptionsView;
import view.modelwizard.v.InitialConfigurationPageView;

public class InitialConfigurationCheckboxOptionsController
{
	private InitialConfigurationCheckboxOptionsModel model;
	private InitialConfigurationCheckboxOptionsView view;
	
	public InitialConfigurationCheckboxOptionsController(InitialConfigurationCheckboxOptionsView view)
	{
		this.view = view;
		this.model = new InitialConfigurationCheckboxOptionsModel();
		
		view.getParentView().getModel().checkboxOptions = this.model;
	}
	
	public InitialConfigurationCheckboxOptionsView getView()
	{
		return this.view;
	}
	
	public InitialConfigurationCheckboxOptionsModel getModel()
	{
		return this.model;
	}
	
	public void refreshOptions()
	{
        if(view.isConfiguredForCAModel())
        {
        	view.setCAOptions();
        	model.setCAModelTrue();
        }
        else
        {
        	view.setNonCAOptions();
        	model.setCAModelFalse();
        }
	}
	
	public void refreshButtons()
	{
		refreshNext();
		refreshFinish();
	}
	
	private InitialConfigurationPageView getParentView()
	{
		return view.getParentView();
	}
	
	private void refreshNext()
	{
        if(getParentView().getModelAndPackageView().isModelSelected() && model.isTrackingSelected())
        {
        	getParentView().setNextEnabled();
        }
        else
        {
        	getParentView().setNextDisabled();
        }
	}
	
	private void refreshFinish()
	{
    	if(getParentView().getModelAndPackageView().isModelSelected() && !model.isTrackingSelected())
    	{
    		getParentView().setFinishEnabled();
    	}
    	else
    	{
    		getParentView().setFinishDisabled();
    	}
	}
	
	public ItemListener onSimViewSelected = new ItemListener() {
		public void itemStateChanged(ItemEvent e) {
            if (e.getStateChange() == ItemEvent.SELECTED)
            {
            	model.setSimViewTrue();
            }
            else
            {
            	model.setSimViewFalse();
            }
		}
	};
       
    public ItemListener onTrackingSelected = new ItemListener() {
		public void itemStateChanged(ItemEvent e) {
            if (e.getStateChange() == ItemEvent.SELECTED)
            {
            	model.setTrackingTrue();
            	refreshButtons();
            }
            else
            {
            	model.setTrackingFalse();
            	getParentView().setNextDisabled();
            	refreshButtons();
            }
        }
	};
	
	public ItemListener onCAButtonPressed = new ItemListener() {
		public void itemStateChanged(ItemEvent e)
		{
			if(e.getStateChange() == ItemEvent.SELECTED)
			{
				View.isCAModel = true;
			}
			else
			{
				View.isCAModel = false;
			}
			
			refreshOptions();
		}
	};
}
