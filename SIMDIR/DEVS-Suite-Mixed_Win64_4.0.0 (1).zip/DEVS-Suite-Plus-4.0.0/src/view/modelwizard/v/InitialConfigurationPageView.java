package view.modelwizard.v;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import view.View;
import view.jwizard.WizardPage;
import view.jwizard.WizardSettings;
import view.modelwizard.c.InitialConfigurationPageController;
import view.modelwizard.m.InitialConfigurationPageModel;

public class InitialConfigurationPageView extends WizardPage
{
	private JPanel panel, center;
	private JButton configureButton;
	private ModelAndPackageView modelAndPackageView;
	private InitialConfigurationCheckboxOptionsView checkboxOptions;
	private FileSystemConfigurationView fileSystemConfigurationView;
	private InitialConfigurationPageController controller;
	private View parentView;
	
	public InitialConfigurationPageView(View parentView)
	{
		super("first", "model configuration");
		createController();
		
		this.parentView = parentView;
		
		panel = new JPanel();
				
		setLayout(new BorderLayout()); 
	    setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        panel.setOpaque(false);
        panel.setLayout(new BorderLayout());
        
		center = new JPanel();

        center.setLayout(new BoxLayout(center, BoxLayout.Y_AXIS));
	        
        modelAndPackageView = new ModelAndPackageView(this);
        center.add(modelAndPackageView);
        
        center.add(Box.createRigidArea(new Dimension(10,10)));
        
        this.checkboxOptions = new InitialConfigurationCheckboxOptionsView(this);
        center.add(this.checkboxOptions);
        
        center.add(createConfigureButton());

        JPanel configuratonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        
        fileSystemConfigurationView = new FileSystemConfigurationView(this);
        fileSystemConfigurationView.setVisible(false);
        configuratonPanel.add(fileSystemConfigurationView);

       	center.add(configuratonPanel);
       	
        panel.add(center, BorderLayout.CENTER);
        super.add(panel);
	}
	
	public View getParentView()
	{
		return this.parentView;
	}
	
	@Override
	public void rendering(List<WizardPage> path, WizardSettings settings)
	{
       	this.setNextDisabled();
       	this.setFinishDisabled();
	}
	
	public void createController()
	{
		this.controller = new InitialConfigurationPageController(this);
	}
	
	public InitialConfigurationPageController getController()
	{
		return this.controller;
	}
	
	public InitialConfigurationPageModel getModel()
	{
		return this.getController().getModel();
	}
	
	@Override
	public Component add(Component component)
	{
		this.center.add(component);
		return this;
	}
	
	private JPanel createConfigureButton()
	{
		JPanel configureButtonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
	     
        configureButton = new JButton("Configure");
        configureButton.setFont(new Font("SansSerif", Font.BOLD, 12));
        configureButton.setHorizontalAlignment(SwingConstants.LEFT);
        configureButton.addActionListener(this.getController().onConfigureButtonPressed);
        configureButtonPanel.add(configureButton);
        
        return configureButtonPanel;
	}
	
	public ModelAndPackageView getModelAndPackageView()
	{
		return this.modelAndPackageView;
	}
	
	public InitialConfigurationCheckboxOptionsView getCheckboxOptions()
	{
		return this.checkboxOptions;
	}
	
	public FileSystemConfigurationView getFileSystemConfigurationView()
	{
		return this.fileSystemConfigurationView;
	}
	
	public void setNextEnabled()
	{
		super.setNextEnabled(true);
	}
	
	public void setNextDisabled()
	{
		super.setNextEnabled(false);
	}
	
	public void setFinishEnabled()
	{
		super.setFinishEnabled(true);
	}
	
	public void setFinishDisabled()
	{
		super.setFinishEnabled(false);
	}
}
