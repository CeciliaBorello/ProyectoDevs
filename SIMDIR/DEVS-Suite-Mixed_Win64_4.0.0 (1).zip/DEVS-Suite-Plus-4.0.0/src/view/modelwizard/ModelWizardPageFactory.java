package view.modelwizard;

import java.util.List;

import view.jwizard.PageFactory;
import view.jwizard.WizardPage;
import view.jwizard.WizardSettings;
import view.modelwizard.v.ComponentTrackingConfigurationPageView;
import view.modelwizard.v.InitialConfigurationPageView;
import view.modelwizard.v.ModelWizardView;

public class ModelWizardPageFactory implements PageFactory
{
	public static final int FIRST_PAGE = 1;
	public static final int SECOND_PAGE = 2;
	private InitialConfigurationPageView firstPage;
	private ComponentTrackingConfigurationPageView secondPage;
	private ModelWizardView parent;
	
	public ModelWizardPageFactory(ModelWizardView parent)
	{
		this.parent = parent;
	}
	
	@Override
	public WizardPage createPage(List<WizardPage> previousPath, WizardSettings settings)
	{
		if(getPageNumber(previousPath) + 1 == FIRST_PAGE)
		{
			if(firstPage == null)
			{
				firstPage = new InitialConfigurationPageView(parent.getParentView());
			}
			return firstPage;
		}
		else if(getPageNumber(previousPath) + 1 == SECOND_PAGE)
		{
			secondPage = new ComponentTrackingConfigurationPageView(parent);
			return secondPage;
		}
		return null;
	}
	
	public int getPageNumber(List<WizardPage> path)
	{
		// "Path" is a stack of visited pages
		return path.size();
	}
	
	public InitialConfigurationPageView getFirstPage()
	{
		return this.firstPage;
	}
	
	public ComponentTrackingConfigurationPageView getSecondPage()
	{
		return this.secondPage;
	};
}
