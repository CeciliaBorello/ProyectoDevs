package CellularAutomata.MOL;

import javafx.scene.paint.Color;
import view.CAView.CAViewUI;

public class MOLUI {
	public static void setPhaseColor() {

//			CAViewUI.setPhaseColorRange({0,0,255}, 0, 100);
		CAViewUI.addPhaseColor("0.0:-", Color.WHITE);
		
	}

}
