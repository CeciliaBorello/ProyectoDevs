package view.modelwizard.v;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;

import facade.modeling.FModel;
import view.Tracker;
import view.modelwizard.PortTrackingConfigurationViewFactory;
import view.modelwizard.c.ComponentTrackingOptionsController;
import view.modelwizard.m.ComponentTrackingOptionsModel;

public class ComponentTrackingOptionsView extends JPanel
{
	private JButton trackButton;
	private TrackingStyleView trackingStyleView;
	private XAxisConfigurationView xAxisConfigurationView;
	private PortTrackingConfigurationView inputPortsView, outputPortsView, stateTrackingView, timeTrackingView;
	private ComponentTrackingOptionsController controller;
	private ComponentTrackingConfigurationPageView parent;
	private JPanel trackingTypePanel;
	
	public ComponentTrackingOptionsView(ComponentTrackingConfigurationPageView parent, Tracker tracker, FModel devsModel)
	{
		this.parent = parent;
		createController(tracker, devsModel);
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		
		trackingTypePanel = new JPanel();
		trackingTypePanel.setLayout(new GridLayout(1, 0));

		trackingStyleView = new TrackingStyleView(this);
	    
		PortTrackingConfigurationViewFactory portFactory = new PortTrackingConfigurationViewFactory(this);

		xAxisConfigurationView = new XAxisConfigurationView(this);

		trackingTypePanel.add(trackingStyleView);
		trackingTypePanel.add(xAxisConfigurationView);
		
		this.add(trackingTypePanel);
		
		this.add(Box.createHorizontalStrut(10));
		
		JPanel statesPanel = new JPanel(new GridLayout(1, 2));

		stateTrackingView = portFactory.makeStatesView();
		timeTrackingView = portFactory.makeTimeDimensionView();
		
		statesPanel.add(stateTrackingView);
		statesPanel.add(timeTrackingView);
		
		this.add(statesPanel);
		this.add(Box.createHorizontalStrut(10));
		
		JPanel portsPanel = new JPanel(new GridLayout(1, 2));
		
        inputPortsView = portFactory.makeInputPortsView();
		outputPortsView = portFactory.makeOutputPortsView();
		
		portsPanel.add(inputPortsView);
		portsPanel.add(outputPortsView);
		
		this.add(portsPanel);
		
		JPanel trackButtonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		trackButtonPanel.add(Box.createRigidArea(new Dimension(20, 1)));
		
		trackButton = new JButton("track");
		trackButton.setFont(new Font("SansSerif", Font.BOLD, 12));
		trackButton.setHorizontalAlignment(SwingConstants.LEFT);
		trackButton.addActionListener(controller.onTrackPressed);

		trackButtonPanel.add(trackButton);
		
		this.add(trackButtonPanel);
		
		Dimension size = this.getPreferredSize();
		size.setSize(size.getWidth(), size.getHeight()/8);
		inputPortsView.setPreferredSize(size);
		outputPortsView.setPreferredSize(size);
		stateTrackingView.setPreferredSize(size);
		timeTrackingView.setPreferredSize(size);
	}
	
	public void createController(Tracker tracker, FModel devsModel)
	{
		this.controller = new ComponentTrackingOptionsController(this, tracker, devsModel);
	}
	
	public ComponentTrackingOptionsController getController()
	{
		return this.controller;
	}
	
	public ComponentTrackingOptionsModel getModel()
	{
		return this.controller.getModel();
	}
	
	public PortTrackingConfigurationView getStateTrackingView()
	{
		return this.stateTrackingView;
	}
	
	public XAxisConfigurationView getXAxisConfigurationView()
	{
		return this.xAxisConfigurationView;
	}
	
	public TrackingStyleView getTrackingStyleView()
	{
		return this.trackingStyleView;
	}
	
	public void enableTrackButton()
	{
		this.trackButton.setEnabled(true);
	}
	
	public void disableTrackButton()
	{
		this.trackButton.setEnabled(false);
	}
	
	public ComponentTrackingConfigurationPageView getParentView()
	{
		return this.parent;
	}
}
