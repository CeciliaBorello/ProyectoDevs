July 2019

For more details and examples refer to the "DEVS-Suite 5.0.0 Instalation Guide with Examples.pdf" document.

DEVS_Suite_5.0.0 
file size: 40.3 MB

Configuration
JRE: 1.8 or JDK 11 + JavaFX 11
OS: Windows 64-bit or Mac osx 64-bit 

This version has the following major additions and updates.

A. The simulator has a directory for its engine and another for models. The engine is in the �src� directory. The models are in the �Models� directory. The modeles directory is divided into the �CellularAutomata� and �Component� categories. Other model packages can be added under their respective directories.

DEVS-Suite-Plus
-src
---controller
----ControllerInterface.java
----Governor.java
----SimLauncher.java
�
---simulation
---modeling
�
-Models
--CellularAutomata
---Agent
---�
--Component
---BasicProcessor
---Counters
---�


B. The Component Tracking is redesigned with more features to design choose data to be tracked.

C. State variable can be tracked using �@state(log = state.DEFAULT_CHECKED)� declarations. See the �multiServerCoord.java� model in the �Component.MultiProcessors� package for an example.

D. The TimeView is using the latest 4.8 BIRT plugin.

E. Supports the JRE 11 with JavaFX 11. 


Installation and execution (Windows and Mac*)

1) Set-up a Java project using your favorite Java IDE. The �Eclipse IDE for Java Developers� is used for the development of this simulator. See �Eclipse Installation for Java 11 and JavaFX 11.pdf� document included in the simulator download.

2) Launch the DEVS-Suite simulator by running the "SimLauncher.java" file which is located in the src.controller package. See "DEVS-Suite 5.0.0 Instalation Guide with Examples.pdf" for launching the simulator for Windows and Mac systems.

3) Select either Component Models or Cellular Automata Models.

4) Select the �Configure File System� in the �model configuration� dialogue box
* set the �Path to packages of model classes (from current folder)� to 'target/classes'
* set the �Path to packages of model source files (from current folder)� to �Models�
* Add packages (e.g., Component.SwitchNetwork) in the �Model package names (one per line)�. The Component.BasicProcessor and CellularAutomata.Agent packages are included in the "Model package name (one per line)". You can delete packages.
* select the OK button 

5) Select a model package from the "Package:" dropdown menu and then choose a model from the �Model:� dropdown menu.

6) Select the "SimView" checkbox if you desire to view simulation steps animated. Similarly, select the "Tracking" checkbox if you desire to have (linear and/or superdense) time trajectories for variables of atomic and coupled component or cellular automata model components.

7) Press the "Finish" button and proceed to the following menus. 