package view.modelwizard.c;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import view.modelwizard.m.InitialConfigurationPageModel;
import view.modelwizard.v.InitialConfigurationPageView;

public class InitialConfigurationPageController
{
	private InitialConfigurationPageView view;
	private InitialConfigurationPageModel model;
	
	public InitialConfigurationPageController(InitialConfigurationPageView view)
	{
		this.view = view;
		this.model = new InitialConfigurationPageModel();
	}
	
	public InitialConfigurationPageModel getModel()
	{
		return this.model;
	}
	
	public ActionListener onConfigureButtonPressed = new ActionListener() {
        public void actionPerformed(ActionEvent e) {
        	 // display the configure dialog
        	 view.getFileSystemConfigurationView().setVisible(true);
        }
    };
	
}
