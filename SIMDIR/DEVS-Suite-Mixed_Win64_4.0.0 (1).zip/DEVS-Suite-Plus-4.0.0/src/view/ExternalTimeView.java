package view;

import java.awt.BorderLayout;
import javax.swing.*;

import view.timeView.GraphsScrollComponent;

public class ExternalTimeView implements Runnable {
	private JFrame frame;
	private String name;
	private JScrollPane TG;
	private String graphName = "";

	public ExternalTimeView(String _name, JScrollPane _TG) {
		name = _name;
		TG = _TG;

		if (((GraphsScrollComponent) TG).getGraphs().size() > 1) {
			String tempName = ": " + ((GraphsScrollComponent) TG).getGraphNames()[0];
			for (int i = 1; i < ((GraphsScrollComponent) TG).getGraphs().size(); i++) {
				tempName = tempName + ", " + ((GraphsScrollComponent) TG).getGraphNames()[i];
			}
			graphName = "- Stack" + tempName;
		} else {
			graphName = "- " + ((GraphsScrollComponent) TG).getGraphNames()[0];
		}
	}

	public void run() {
		frame = new JFrame(name + " " + graphName);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		JComponent newContentPane = new JPanel(new BorderLayout());
		newContentPane.add(TG, BorderLayout.CENTER);
		newContentPane.setOpaque(true); // content panes must be opaque
		frame.setIconImage(new ImageIcon(ViewUtils.loadFullImage(ViewUtils.LOGO)).getImage());
		frame.setContentPane(newContentPane);
		frame.pack();
		frame.setVisible(true);
	}

	public void dispose() {
		frame.dispose();
	}

	public String getName() {
		return name;
	}

	public void setInvisible() {
		frame.setVisible(false);
	}

	public boolean getInvisible() {
		return frame.isVisible();
	}

}
