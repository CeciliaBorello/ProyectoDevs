package view.modelwizard.m;

public class InitialConfigurationCheckboxOptionsModel
{
	private boolean isSimViewSelected, isTrackingSelected, isCAModelSelected;
	
	public InitialConfigurationCheckboxOptionsModel()
	{
		isSimViewSelected = false;
		isTrackingSelected = false;
	}
	
	public void setSimViewFalse()
	{
		this.isSimViewSelected = false;
	}
	
	public void setTrackingFalse()
	{
		this.isTrackingSelected = false;
	}
	
	public void setSimViewTrue()
	{
		this.isSimViewSelected = true;
	}
	
	public void setTrackingTrue()
	{
		this.isTrackingSelected = true;
	}
	
	public void setCAModelTrue()
	{
	    this.isCAModelSelected = true;
	}
	
	public void setCAModelFalse()
	{
	    this.isCAModelSelected = false;
	}
	
	public boolean isSimViewSelected()
	{
		return this.isSimViewSelected;
	}
	
	public boolean isTrackingSelected()
	{
		return this.isTrackingSelected;
	}
	
	public boolean isCAModel()
	{
		return this.isCAModelSelected;
	}
}
