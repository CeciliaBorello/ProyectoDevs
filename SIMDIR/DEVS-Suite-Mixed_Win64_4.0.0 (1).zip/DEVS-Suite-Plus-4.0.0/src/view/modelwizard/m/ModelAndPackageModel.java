package view.modelwizard.m;

import java.util.ArrayList;
import java.util.List;

public class ModelAndPackageModel
{
	private List<String> packagesList, modelsList;
	
	public ModelAndPackageModel()
	{
		this.packagesList = new ArrayList<String>();
		this.modelsList = new ArrayList<String>();
	}
	
	public boolean isModelsListEmpty()
	{
		return this.modelsList.isEmpty();
	}
	
	public boolean isPackagesListEmpty()
	{
		return this.packagesList.isEmpty();
	}
	
	public void clearModelsList()
	{
		this.modelsList.clear();
	}
	
	public void clearPackagesList()
	{
		this.packagesList.clear();
	}
	
	public List<String> getModelsList()
	{
		return this.modelsList;
	}
	
	public List<String> getPackagesList()
	{
		return this.packagesList;
	}
	
	public void addPackage(String pkg)
	{
		this.packagesList.add(pkg);
	}
	
	public void addModel(String model)
	{
		this.modelsList.add(model);
	}
}
