package view.modelwizard.v;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.BorderFactory;
import javax.swing.JCheckBox;
import javax.swing.JPanel;

import view.Tracker;
import view.modelwizard.c.TrackingStyleController;

public class TrackingStyleView extends JPanel
{
	private static final long serialVersionUID = -8419603016376931106L;
	private JCheckBox timeView, timeViewSeparated, htmlTracking;
	private TrackingStyleController controller;
	private ComponentTrackingOptionsView parent;
	
	public TrackingStyleView(ComponentTrackingOptionsView parent)
	{
		super.setLayout(new BorderLayout());
		super.setBorder(BorderFactory.createTitledBorder("View Options"));

		this.parent = parent;
		
		createController();
		
		JPanel timeViewPanel = new JPanel(new FlowLayout());
		
		Tracker tracker = getController().getTracker();
		
		timeView = new JCheckBox("TimeView", tracker.getTimeViewSelected());
		timeView.addItemListener(this.getController().onTimeViewChanged);
		timeViewPanel.add(timeView);
		
		htmlTracking = new JCheckBox("Tracking Log", tracker.getTrackingLogSelected());
		htmlTracking.addItemListener(this.getController().onHTMLTrackingChanged);
		timeViewPanel.add(htmlTracking);

		timeViewSeparated = new JCheckBox("TimeView Separate ", tracker.getTimeViewSelected());
		timeViewSeparated.addItemListener(this.getController().onTimeViewSeparatedChanged);
		timeViewPanel.add(timeViewSeparated);
		
		this.add(timeViewPanel);
	}
	
	public void createController()
	{
		this.controller = new TrackingStyleController(this);
	}
	
	public ComponentTrackingOptionsView getParentView()
	{
		return this.parent;
	}
	
	public boolean isTimeViewSelected()
	{
		return this.timeView.isSelected();
	}
	
	public boolean isTimeViewSeparatedSelected()
	{
		return this.timeViewSeparated.isSelected();
	}
	
	public boolean isHTMLTrackingSelected()
	{
		return this.htmlTracking.isSelected();
	}
	
	public TrackingStyleController getController()
	{
		return this.controller;
	}
	
	public void enableTrackButton()
	{
		this.parent.enableTrackButton();
	}
	
	public void disableTrackButton()
	{
		this.parent.disableTrackButton();
	}
}
