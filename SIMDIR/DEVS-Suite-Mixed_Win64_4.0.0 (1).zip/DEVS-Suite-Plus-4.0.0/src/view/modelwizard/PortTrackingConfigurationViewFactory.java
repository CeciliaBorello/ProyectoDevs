package view.modelwizard;

import view.modelwizard.m.ComponentTrackingOptionsModel;
import view.modelwizard.v.ComponentTrackingOptionsView;
import view.modelwizard.v.PortTrackingConfigurationView;

public class PortTrackingConfigurationViewFactory
{
	private ComponentTrackingOptionsView view;
	
	public PortTrackingConfigurationViewFactory(ComponentTrackingOptionsView view)
	{
		this.view = view;
	}
	
	public PortTrackingConfigurationView makeInputPortsView()
	{
		ComponentTrackingOptionsModel viewModel = view.getModel();
		return new PortTrackingConfigurationView("Input Ports", 
												 viewModel.getInputPortUnits(), 
												 viewModel.getTrackInputPortsStacked(),
												 viewModel.getTrackInputPortsSeparate(),
												 viewModel.getInputPortNames());
	}
	
	public PortTrackingConfigurationView makeOutputPortsView()
	{
		ComponentTrackingOptionsModel viewModel = view.getModel();
		return new PortTrackingConfigurationView("Output Ports", 
												 viewModel.getOutputPortUnits(), 
												 viewModel.getTrackOutputPortsStacked(),
												 viewModel.getTrackOutputPortsSeparate(),
												 viewModel.getOutputPortNames());
	}
	
	public PortTrackingConfigurationView makeStatesView()
	{
	    ComponentTrackingOptionsModel viewModel = view.getModel();
	    return new PortTrackingConfigurationView("States",
	                                             viewModel.getStateUnits(),
	                                             viewModel.getTrackStateStack(),
	                                             viewModel.getTrackStateSeparate(),
	                                             viewModel.getStateNames());
	}
	
    public PortTrackingConfigurationView makeTimeDimensionView()
    {
        ComponentTrackingOptionsModel viewModel = view.getModel();
        return new PortTrackingConfigurationView("Time",
                                                 viewModel.getTimeUnits(),
                                                 viewModel.getTrackTimeDimensionStack(),
                                                 viewModel.getTrackTimeDimensionSeparate(),
                                                 viewModel.getTimeDimensionNames());
    }
}
