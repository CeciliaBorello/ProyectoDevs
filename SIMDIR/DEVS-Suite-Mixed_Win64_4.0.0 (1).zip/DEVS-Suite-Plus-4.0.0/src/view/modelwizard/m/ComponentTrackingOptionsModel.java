package view.modelwizard.m;

import java.util.ArrayList;
import java.util.List;

import javax.swing.tree.DefaultMutableTreeNode;

import facade.modeling.FAtomicModel;
import facade.modeling.FModel;
import view.Tracker;
import view.timeView.Graph;

public class ComponentTrackingOptionsModel
{
	private Tracker tracker;
	private FModel devsModel;
	
	public ComponentTrackingOptionsModel(Tracker tracker, FModel devsModel)
	{
		this.tracker = tracker;
		this.devsModel = devsModel;
	}
	
	public Tracker getTracker()
	{
		return this.tracker;
	}
	
	public FModel getDEVSModel()
	{
		return this.devsModel;
	}
	
	public boolean isAtomicDEVS()
	{
		return this.devsModel instanceof FAtomicModel;
	}
	
	public ArrayList<Graph> getGraphs()
	{
		return this.tracker.getGraphs();
	}
	
	public List<String> getInputPortNames()
	{
		return this.devsModel.getInputPortNames();
	}
	
	public List<String> getOutputPortNames()
	{
		return this.devsModel.getOutputPortNames();
	}
	
	public String[] getInputPortUnits()
	{
		return this.tracker.getInputPortUnits();
	}
	
	public String[] getOutputPortUnits()
	{
		return this.tracker.getOutputPortUnits();
	}
	
	public String[] getTimeUnits()
	{
	    return this.tracker.getTimeUnits();
	}
	
	public String getTimeUnitsAt(int index)
	{
	    return index < getTimeUnits().length ? getTimeUnits()[index] : null;
	}
	
	public boolean[] getTrackInputPortsStacked()
	{
		return this.tracker.gettrackInputPortsStack();
	}
	
	public boolean getTrackInputPortsStackedAt(int index)
	{
		return this.tracker.gettrackInputPortsStack()[index];
	}
	
	public boolean getTrackInputPortsSeparateAt(int index)
	{
		return this.tracker.gettrackInputPortsSeparate()[index];
	}
	
	public boolean[] getTrackInputPortsSeparate()
	{
		return this.tracker.gettrackInputPortsSeparate();
	}
	
	public boolean getTrackOutputPortsStackAt(int index)
	{
		return this.tracker.gettrackOutputPortsStack()[index];
	}
	
	public boolean getTrackOutputPortsSeparateAt(int index)
	{
		return this.tracker.gettrackOutputPortsSeparate()[index];
	}
	
	public boolean[] getTrackOutputPortsStacked()
	{
		return this.tracker.gettrackOutputPortsStack();
	}
	
	public boolean[] getTrackOutputPortsSeparate()
	{
		return this.tracker.gettrackOutputPortsSeparate();
	}
	
	public String getInputPortName(int index)
	{
		return index < this.getInputPortNames().size() ? this.getInputPortNames().get(index) : null;
	}
	
	public String getOutputPortName(int index)
	{
		return index < this.getOutputPortNames().size() ? this.getOutputPortNames().get(index) : null;
	}
	
	public String getInputPortUnit(int index)
	{
		return index < this.getInputPortUnits().length ? this.getInputPortUnits()[index] : null;
	}
	
	public String getOutputPortUnit(int index)
	{
		return index < this.getOutputPortUnits().length ? this.getOutputPortUnits()[index] : null;
	}
	
	public String[] getStateUnits()
	{
	    return this.tracker.getStateUnits();
	}
	
	public String getStateUnitAt(int index)
	{
	    return index < this.getStateUnits().length ? this.getStateUnits()[index] : null;
	}
	
	public boolean[] getTrackStateStack()
	{
	    return this.tracker.getTrackStateStack();
	}
	
	public boolean getTrackStateStackAt(int index)
	{
	    return index < this.getTrackStateStack().length ? this.getTrackStateStack()[index] : null;
	}
	
	public boolean[] getTrackStateSeparate()
	{
	    return this.tracker.getTrackStateSeparate();
	}
	
	public boolean getTrackStateSeparateAt(int index)
	{
	    return index < this.getTrackStateSeparate().length ? this.getTrackStateSeparate()[index] : null;
	}
	
	public boolean[] getTrackTimeDimensionStack()
	{
	    return this.tracker.getTrackTimeDimensionStack();
	}
	
	public boolean getTrackTimeDimensionStackAt(int index)
	{
	    return index < getTrackTimeDimensionStack().length ? getTrackTimeDimensionStack()[index] : null;
	}
	
    public boolean[] getTrackTimeDimensionSeparate()
    {
        return this.tracker.getTrackTimeDimensionSeparate();
    }
    
    public boolean getTrackTimeDimensionSeparateAt(int index)
    {
        return index < getTrackTimeDimensionSeparate().length ? getTrackTimeDimensionSeparate()[index] : null;
    }
	
	public List<String> getTimeDimensionNames()
	{
	    return this.devsModel.getTimeDimensionNames();
	}
	
	public String getTimeDimensionNameAt(int index)
	{
	    return index < getTimeDimensionNames().size() ? getTimeDimensionNames().get(index) : null;
	}
	
	public List<String> getStateNames()
	{
	    return this.devsModel.getStateNames();
	}
	
	public String getStateNameAt(int index)
	{
	    return index < this.getStateNames().size() ? this.getStateNames().get(index) : null;
	}
}
