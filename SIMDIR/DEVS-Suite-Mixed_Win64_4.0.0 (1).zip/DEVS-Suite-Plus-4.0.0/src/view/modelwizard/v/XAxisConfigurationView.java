package view.modelwizard.v;

import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import view.Tracker;
import view.modelwizard.c.XAxisConfigurationController;

public class XAxisConfigurationView extends JPanel
{
	private static final long serialVersionUID = -9100043383188207382L;
	private JTextField xAxisUnit, timeIncrement;
	private JCheckBox showZeroTimeAdvance;
	
	private ComponentTrackingOptionsView parent;
	private XAxisConfigurationController controller;
	
	public XAxisConfigurationView(ComponentTrackingOptionsView parent)
	{
		this.parent = parent;
		createController();
		
		xAxisUnit = new JTextField(getTracker().getxUnit());
		xAxisUnit.setHorizontalAlignment(JTextField.RIGHT);
		JPanel axisPanel = new JPanel();
		axisPanel.setLayout(new FlowLayout());
		JLabel xaxis = new JLabel("X-Axis");
		JPanel unitPane = new JPanel(new GridLayout(1, 2));
		unitPane.add(xaxis);
		unitPane.add(xAxisUnit);
		axisPanel.add(unitPane);

		// Time Increment
		timeIncrement = new JTextField(getTracker().gettimeIncrement());
		timeIncrement.setHorizontalAlignment(JTextField.RIGHT);
		JLabel time = new JLabel("Increment");
		unitPane = new JPanel(new GridLayout(1, 2));
		unitPane.add(time);
		unitPane.add(timeIncrement);
		axisPanel.add(unitPane);

		// zerotime advance
		showZeroTimeAdvance = new JCheckBox("ZeroTimeAdvance plots", false);
		unitPane = new JPanel(new GridLayout(1, 2));
		unitPane.add(showZeroTimeAdvance);
		axisPanel.add(unitPane);

		showZeroTimeAdvance.addItemListener(getController().onShowZeroTimeAdvanceChanged);
		
		this.setBorder(BorderFactory.createTitledBorder("X-Axis/Unit"));
		this.add(axisPanel);
	}
	
	public void createController()
	{
		this.controller = new XAxisConfigurationController(this);
	}
	
	public XAxisConfigurationController getController()
	{
		return this.controller;
	}
	
	private Tracker getTracker()
	{
		return this.parent.getModel().getTracker();
	}
	
	public ComponentTrackingOptionsView getParentView()
	{
		return this.parent;
	}
	
	public JTextField getTimeIncrement()
	{
		return this.timeIncrement;
	}
	
	public JTextField getXAxisUnit()
	{
		return this.xAxisUnit;
	}
	
	public boolean isZeroTimeAdvanceChecked()
	{
		return this.showZeroTimeAdvance.isSelected();
	}
}
