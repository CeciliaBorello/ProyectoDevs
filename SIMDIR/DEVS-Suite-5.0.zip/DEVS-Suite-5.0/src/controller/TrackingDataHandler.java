package controller;

public interface TrackingDataHandler {	
	public String getCSVExport();
	public String[] getEncodedCSVExport();
	public String getHTMLTrackingLog();
}
