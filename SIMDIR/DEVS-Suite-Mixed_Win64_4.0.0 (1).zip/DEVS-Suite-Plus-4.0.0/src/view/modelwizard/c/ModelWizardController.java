package view.modelwizard.c;

import java.util.List;

import view.ModelTrackingDataHandler;
import view.Tracker;
import view.TrackingControl;
import view.View;
import view.jwizard.WizardListener;
import view.jwizard.WizardPage;
import view.jwizard.WizardSettings;
import view.modelwizard.ModelWizardPageFactory;
import view.modelwizard.m.ModelWizardModel;
import view.modelwizard.v.ModelWizardView;

public class ModelWizardController
{
	private ModelWizardView view;
	private ModelWizardModel model;
	
	public ModelWizardController(ModelWizardView view)
	{
		this.view = view;
		this.model = new ModelWizardModel();
	}
	
	public ModelWizardModel getModel()
	{
		return this.model;
	}
	
	private View getParentView()
	{
		return this.view.getParentView();
	}
	
	private int getPageNumber(List<WizardPage> path)
	{
		return view.getPageFactory().getPageNumber(path);
	}
	
	private boolean isSecondPage(List<WizardPage> path)
	{
		return getPageNumber(path) == ModelWizardPageFactory.SECOND_PAGE;
	}
	
	private void saveSettings()
	{
		view.getFirstPage().getFileSystemConfigurationView().getController().saveSettings();
	}
	
	public WizardListener onWizardPageChanged = new WizardListener(){
    	@Override
        public void onCanceled(List<WizardPage> path, WizardSettings settings)
    	{
           view.dispose();
    	}
    	
        @Override
        public void onFinished(List<WizardPage> path, WizardSettings settings)
        {
        	TrackingControl addTrack = null;
        	view.dispose();
        	if(!isSecondPage(path))
        	{ 
        		getParentView().setLastModelViewed(getParentView().modelName);
        		getParentView().loadModelAction();	 
        		saveSettings();
        	}
        	else
        	{   
        		for(Tracker tracker : view.getParentView().modelView.getTrackingControl().getTrackers())
        		{
	        		if(tracker.getTrackingLogSelected())
	        		{
	        			ModelTrackingDataHandler trackingHandler = new ModelTrackingDataHandler(getParentView().modelView);
	        			getParentView().controller.registerTrackingDataHandler(trackingHandler);
	                    tracker.getTrackingControl()
	                    	   .registerTrackingLog(trackingHandler);   
	                    
	                    addTrack = tracker.getTrackingControl();
                	}

	        		if(tracker.getTimeViewSelected())
	        		{	
                		tracker.getTrackingControl()
                		       .registerTimeView(tracker.getGraphs(), 
                		    		             tracker.getModelNum(), 
                		    		             tracker.getxUnit(), 
                		    		             tracker.gettimeIncrement(),
                		    		             tracker.getisBreakout()); 
                		
                		addTrack = tracker.getTrackingControl();
	        		}
        		 }
        		if(addTrack != null)
        		addTrack.addTracking(0.0); 
        	
        	}
         }
        
         @Override
         public void onPageChanged(WizardPage newPage, List<WizardPage> path)
         {
        	 if(isSecondPage(path))
        	 {
        		 saveSettings();
                 view.setSize(1100, 600);
        	 }
        	 else
        	 {
        		 view.getFirstPage().getCheckboxOptions().getController().refreshButtons();
                 view.setSize(650, 600);
        	 }
        	 // Set the dialog title to match the description of the new page:
        	 getParentView().setLastModelViewed(getParentView().modelName);

        	 view.setTitle(newPage.getDescription());
         }
  };
}
