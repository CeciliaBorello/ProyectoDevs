package view.modelwizard.c;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import view.modelwizard.v.XAxisConfigurationView;
import view.timeView.Graph;

public class XAxisConfigurationController
{
	private XAxisConfigurationView view;
	
	public XAxisConfigurationController(XAxisConfigurationView view)
	{
		this.view = view;
	}
	
	public ItemListener onShowZeroTimeAdvanceChanged = new ItemListener() {
		public void itemStateChanged(ItemEvent e)
		{
			if (e.getStateChange() == ItemEvent.SELECTED)
			{
				for (Graph graph : view.getParentView().getModel().getGraphs())
				{
					graph.setZeroTimeAdvance(true);
				}
			} 
			else
			{
				for (Graph graph : view.getParentView().getModel().getGraphs())
				{
					graph.setZeroTimeAdvance(false);
				}
			}
		}
	};
}
