package view.modelwizard.v;

import java.awt.Dimension;
import java.awt.Event;
import java.awt.event.KeyEvent;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.text.DefaultEditorKit;
import javax.swing.text.Keymap;

import view.modelwizard.c.FileSystemConfigurationController;
import view.modelwizard.m.FileSystemConfigurationModel;

public class FileSystemConfigurationView extends JPanel
{
	private static final long serialVersionUID = 4714714601191760403L;
	private FileSystemConfigurationController controller;
	private JTextField classPathField, sourcePathField;
	private JTextArea packagesArea;
	private InitialConfigurationPageView parent;
	
	public FileSystemConfigurationView(InitialConfigurationPageView parent)
	{
		this.parent = parent;
		createController();
		
		// have the close-window button do nothing for this dialog
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        // add the class path label
        JLabel label = new JLabel("Path to packages of model classes (from current folder)");
        label.setAlignmentX(0.0f);
        add(label);

        // add the class path field
        classPathField = new JTextField(getModel().getClassPath());
        classPathField.setAlignmentX(0.0f);
        add(classPathField);

        // limit the height of the class path field
        classPathField.setMaximumSize(new Dimension(1000,
            (int)(1.5 * parent.getParentView().getFontMetrics(classPathField.getFont()).getHeight())));

        add(Box.createRigidArea(new Dimension(0, 10)));

        // add the source path label
        label = new JLabel("Path to packages of model source files (from current folder)");
        label.setAlignmentX(0.0f);
        add(label);

        // add the source path field
        sourcePathField = new JTextField(getModel().getSourcePath());
        sourcePathField.setAlignmentX(0.0f);
        add(sourcePathField);

        // limit the height of the source path field
        sourcePathField.setMaximumSize(new Dimension(1000,
            (int)(1.5 * parent.getParentView().getFontMetrics(sourcePathField.getFont()).getHeight())));

        add(Box.createRigidArea(new Dimension(0, 10)));

        // add the package names label
        label = new JLabel("Model package names (one per line)");
        label.setAlignmentX(0.0f);
        add(label);

        // add the package names text area
        packagesArea = new JTextArea();
        this.getController().refreshPackageAreaFieldFromModel();
        
        JScrollPane scrollPane = new JScrollPane(packagesArea);
        scrollPane.setAlignmentX(0.0f);
        add(scrollPane);

        // have ctrl-insert do a copy action in the text area
        Keymap keymap = packagesArea.addKeymap(null, packagesArea.getKeymap());
        KeyStroke key = KeyStroke.getKeyStroke(KeyEvent.VK_INSERT,
            Event.CTRL_MASK);
        keymap.addActionForKeyStroke(key, new DefaultEditorKit.CopyAction());

        // have shift-insert do a paste action in the text area
        key = KeyStroke.getKeyStroke(KeyEvent.VK_INSERT, Event.SHIFT_MASK);
        keymap.addActionForKeyStroke(key,
            new DefaultEditorKit.PasteAction());
        packagesArea.setKeymap(keymap);

        add(Box.createRigidArea(new Dimension(0, 10)));

        JPanel panel = new JPanel();
        panel.setOpaque(false);
        panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));
        panel.setAlignmentX(0.0f);
        add(panel);

        panel.add(Box.createHorizontalGlue());

        // add the ok button
        JButton okButton = new JButton("Ok");
        okButton.setAlignmentX(0.0f);
        panel.add(okButton);

        // when the ok button is clicked
        okButton.addActionListener(this.getController().onOkPressed);
	}
	
	public void createController()
	{
		this.controller = new FileSystemConfigurationController(this);
	}
	
	public InitialConfigurationPageView getParentView()
	{
		return this.parent;
	}
	
	public FileSystemConfigurationController getController()
	{
		return this.controller;
	}
	
	public FileSystemConfigurationModel getModel()
	{
		return this.getController().getModel();
	}
	
	public JTextField getClassPathField()
	{
		return this.classPathField;
	}
	
	public JTextField getSourcePathField()
	{
		return this.sourcePathField;
	}
	
	public JTextArea getPackagesArea()
	{
		return this.packagesArea;
	}
	
	public void setInvisible()
	{
		this.setVisible(false);
	}
}
