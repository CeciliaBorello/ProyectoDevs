package view.modelwizard;

import java.awt.Color;
import java.awt.Component;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;

import facade.modeling.FModel;
import view.modelwizard.v.ComponentTrackingConfigurationPageView;

public class ModelHierarchyRenderer extends DefaultTreeCellRenderer
{

	private static final long serialVersionUID = -6955519655472260836L;
	private ComponentTrackingConfigurationPageView parent;

	public ModelHierarchyRenderer(ComponentTrackingConfigurationPageView parent)
	{
		this.parent = parent;
	}

	public Component getTreeCellRendererComponent(JTree tree, Object value, boolean sel, boolean expanded, boolean leaf,
			int row, boolean hasFocus)
	{
		super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf, row, hasFocus);

		if (isTrackedNode((DefaultMutableTreeNode) value))
		{
			setBackgroundNonSelectionColor(Color.GREEN);
		} else
		{
			setBackgroundNonSelectionColor(null);
		}

		return this;
	}

	protected boolean isTrackedNode(DefaultMutableTreeNode node)
	{
		return parent.getModel().trackedNodesContains((FModel) node.getUserObject());
	}
}