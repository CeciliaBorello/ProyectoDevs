/**
  * Facade connection: View provides the VIEW functionalities
 * Integrated the Timeview and Simview into the original tracking environment
 * 
 * @modified Sungung Kim
 * @date 5/12/2008
 */

package view;

import facade.simulation.*;
import facade.simulation.CAsimulation.FCASimulator;
import javafx.application.Platform;

//Standard API Imports
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import javax.swing.*;
import controller.ControllerInterface;
import view.CAView.CATrackingControl;
import view.CAView.SpaceView;
import view.modelwizard.ModelWizard;
import view.simView.*;

public class View extends JFrame implements ViewInterface {
	public static JFrame PARENT_FRAME;
	private JToolBar DEVSToolBar;

	private int consoleTabIndex = 0;

	private ConsoleComponent console;

	// private ModelTrackingComponent tracking;
	private TrackingControl tracking;
	private CATrackingControl catracking;

	public FModelView modelView; // Tree structured model viewer
	private FSimulatorView simulatorView; // Controller viewer
	private FSimulatorSCView simSCView;
	public ControllerInterface controller;
	private SimView sim;
	private SplashScreen splashScreen;
	private JMenuItem[] modelMenus;
	public static JMenuItem[] controlMenus;

	public static JButton[] ButtonControls;

	// Panel component
	// viewOptions = simPane + consolePane
	// splitPane = left + viewOptions
	private JSplitPane viewOptions, splitPane;
	private JPanel simPane, consolePane, leftPane;

	public String modelName;
	public static String curPackages;
	private String lastModelViewed;
	private String currentDirectory;
	private String sourcePath;

	private static ModelWizard modelWizard;
	public static boolean isCAModel = false;

	public static JTabbedPane tabbedPane;

	public View(ControllerInterface controller) {
		super(ViewUtils.FRAME_TITLE);

		// Start screen
		splashScreen = new SplashScreen();
		splashScreen.setSplashImage(ViewUtils.loadFullImage(ViewUtils.SPLASH_SCREEN_ICON));
		// splashScreen.startSplashScreen();

		setSize(ViewUtils.FRAME_DIM);

		// Center of the Frame
		Dimension screenDim = Toolkit.getDefaultToolkit().getScreenSize();
		setLocation(new Point((screenDim.width - ViewUtils.FRAME_DIM.width) / 2,
				(screenDim.height - ViewUtils.FRAME_DIM.height) / 2));

		PARENT_FRAME = this;
		this.controller = controller;

		// Construct UI for the DevsSuite
		UIconstruct();

		final ControllerInterface c = controller;

		addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(WindowEvent evt) {
				if (isSimView())
					sim.saveModelLayout();
				c.systemExitGesture();
			}
		});

		// splashScreen.endSplashScreen(this);

		modelWizard = new ModelWizard(this);
	}

	// adding by Chao, first loaded page will be load model and the original
	// Swing page will be disabled.
	public void createLoadPage() {
		this.setVisible(false);

		new StartChoice();
	}

	// adding by Chao, disable Swing display by default
	public void setSwingVisible(boolean b) {

		this.setVisible(b);
	}

	/**
	 * this method create the UI for the DEVSSuite
	 */
	private void UIconstruct() {

		/* Added Logo for DEVS-Suite */
		this.setIconImage(new ImageIcon(ViewUtils.loadFullImage(ViewUtils.LOGO)).getImage());

		// console panel & tracking control
		console = new ConsoleComponent();
		tracking = new TrackingControl();
		catracking = new CATrackingControl();
		console.redirectOutAndErrStreams();
		tabbedPane = new JTabbedPane();
		tabbedPane.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);

		// Facade Components
		modelView = new FModelView(controller, tracking);
		sim = new SimView();
		simulatorView = new FSimulatorView(controller);
		simSCView = new FSimulatorSCView();

		// The animation panel & console panel
		simPane = new JPanel(new BorderLayout()); // panel for the animation

		consolePane = new JPanel(new BorderLayout());
		consolePane.add(console, BorderLayout.CENTER);

		tabbedPane.add(consolePane, consoleTabIndex);
		tabbedPane.setTitleAt(consoleTabIndex, "Console");

		// View panel
		viewOptions = new JSplitPane(JSplitPane.VERTICAL_SPLIT, simPane, tabbedPane);
		viewOptions.setDividerLocation(400);
		viewOptions.setOneTouchExpandable(true);

		// Left panel including model tree and controller
		leftPane = new JPanel();
		leftPane.setLayout(new BorderLayout());
		leftPane.add(modelView);
		leftPane.add(simulatorView, BorderLayout.SOUTH);

		// Main structure : Left(leftPane) and Right(viewOptions)
		splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftPane, viewOptions);
		splitPane.setDividerLocation(260);
		splitPane.setOneTouchExpandable(true);
		getContentPane().add(splitPane, java.awt.BorderLayout.CENTER);

		setJMenuBar(CreateMenuBar());
		getContentPane().add(CreateToolBar(), java.awt.BorderLayout.NORTH);

		console.setVisible(true);
	}

	/**
	 * This method will create tool bar for the application
	 * 
	 * @return ToolBar
	 */
	private JToolBar CreateToolBar() {

		DEVSToolBar = new JToolBar();

		// New simulation
		JButton button = new JButton(new ImageIcon(ViewUtils.loadFullImage(ViewUtils.NEW_MENU)));
		button.setToolTipText("New");
		DEVSToolBar.add(button);

		View self = this;
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// if no model is selected, then call LoadModel()
				// else reload a model
				if (curPackages == null && modelName == null) {
					modelWizard.openDialog();
				} else
					reloadModelAction();
			}
		});

		// load a model
		button = new JButton(new ImageIcon(ViewUtils.loadFullImage(ViewUtils.OPEN_MENU)));
		button.setToolTipText("Load Model");
		DEVSToolBar.add(button);

		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				modelWizard.openDialog();
			}
		});

		// Separator
		DEVSToolBar.addSeparator();

		// save console log
		button = new JButton(new ImageIcon(ViewUtils.loadFullImage(ViewUtils.SAVE_MENU)));
		button.setToolTipText("Save Console Log");
		DEVSToolBar.add(button);

		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getConsoleLog();
			}
		});

		// Clean console
		button = new JButton(new ImageIcon(ViewUtils.loadFullImage(ViewUtils.CLEAN_MENU)));
		button.setToolTipText("Clean Console");
		DEVSToolBar.add(button);

		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clearConsoleAction();
			}
		});

		// Console Setting
		button = new JButton(new ImageIcon(ViewUtils.loadFullImage(ViewUtils.SETTING_MENU)));
		button.setToolTipText("Console Setting");
		DEVSToolBar.add(button);

		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				console.customizeComponent(PARENT_FRAME);
			}
		});

		// Separator
		DEVSToolBar.addSeparator();

		// About
		button = new JButton(new ImageIcon(ViewUtils.loadFullImage(ViewUtils.HELP_MENU)));
		button.setToolTipText("About");
		DEVSToolBar.add(button);

		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				showAboutBox();
			}
		});

		// Separator
		DEVSToolBar.addSeparator();

		DEVSToolBar.add(Box.createRigidArea(new Dimension(250, 10)));

		initializeController();

		DEVSToolBar.setFloatable(false);

		return DEVSToolBar;
	}

	private void initializeController() {

		ButtonControls = new JButton[5];

		ButtonControls[0] = new JButton(new ImageIcon(ViewUtils.loadFullImage(ViewUtils.STEP)));
		ButtonControls[0].setToolTipText("Step");
		DEVSToolBar.add(ButtonControls[0]);

		ButtonControls[0].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.userGesture(controller.SIM_STEP_GESTURE, null);
			}
		});

		ButtonControls[1] = new JButton(new ImageIcon(ViewUtils.loadFullImage(ViewUtils.STEPN)));
		ButtonControls[1].setToolTipText("Step(n)");
		DEVSToolBar.add(ButtonControls[1]);

		ButtonControls[1].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String val = JOptionPane.showInputDialog(View.PARENT_FRAME, "Number of steps to iterate: ");
				if (val != null)
					try {
						Integer i = new Integer(val);
						controller.userGesture(controller.SIM_STEPN_GESTURE, i);
					} catch (Exception exp) {
						System.err.println(exp);
					}
			}
		});

		ButtonControls[2] = new JButton(new ImageIcon(ViewUtils.loadFullImage(ViewUtils.RUN)));
		ButtonControls[2].setToolTipText("Run");
		DEVSToolBar.add(ButtonControls[2]);

		ButtonControls[2].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.userGesture(controller.SIM_RUN_GESTURE, null);
			}
		});

		ButtonControls[3] = new JButton(new ImageIcon(ViewUtils.loadFullImage(ViewUtils.PAUSE)));
		ButtonControls[3].setToolTipText("Pause");
		DEVSToolBar.add(ButtonControls[3]);

		ButtonControls[3].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.userGesture(controller.SIM_PAUSE_GESTURE, null);
			}
		});

		ButtonControls[4] = new JButton(new ImageIcon(ViewUtils.loadFullImage(ViewUtils.RSET)));
		ButtonControls[4].setToolTipText("Reset");
		DEVSToolBar.add(ButtonControls[4]);

		ButtonControls[4].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String msg = "Reset this Model?\n";
				msg += "All Tracking Data Will Be Lost";
				int option = JOptionPane.showConfirmDialog(View.PARENT_FRAME, msg, "Reset Model?",
						JOptionPane.YES_NO_OPTION);
				if (option == JOptionPane.YES_OPTION)
					controller.userGesture(controller.SIM_RESET_GESTURE, null);
			}
		});

		for (int i = 0; i < ButtonControls.length; i++) {
			ButtonControls[i].setVisible(false);
		}
	}

	/**
	 * This function creates the menubar
	 * 
	 * @return menubar
	 */
	private JMenuBar CreateMenuBar() {

		JMenuBar menuBar = new JMenuBar();

		MenuActionListener menuListener = new MenuActionListener(this);

		modelMenus = new JMenuItem[7];
		modelMenus[0] = new JMenuItem("Reload Model", 'R');
		modelMenus[1] = new JMenuItem("Save Tracking Log...", 'T');
		modelMenus[2] = new JMenuItem("Tracking Log Settings...", 'T');
		modelMenus[3] = new JMenuItem("Export to CSV...", 'C');
		modelMenus[4] = new JMenuItem("Export to Encoded CSV...", 'E');
		modelMenus[5] = new JMenuItem("Refresh Tracking Log", 'R');
		modelMenus[6] = new JMenuItem("Save Console Log...", 'S');

		for (int i = 0; i < modelMenus.length - 1; i++)
			modelMenus[i].setEnabled(false);

		controlMenus = new JMenuItem[5];
		controlMenus[0] = new JMenuItem("Step", 'S');
		controlMenus[1] = new JMenuItem("Step(n)", 'N');
		controlMenus[2] = new JMenuItem("Run", 'R');
		controlMenus[3] = new JMenuItem("Pause", 'P');
		controlMenus[4] = new JMenuItem("Reset", 'E');

		for (int i = 0; i < controlMenus.length; i++)
			controlMenus[i].setEnabled(false);

		// Create File Menu
		JMenu fileMenu = new JMenu("File");

		fileMenu.setMnemonic('F');

		menuBar.add(
				ViewUtils.makeMenu(
						fileMenu, new Object[] { new JMenuItem("Load Model...", 'L'), null, modelMenus[6],
								modelMenus[1], null, modelMenus[3], modelMenus[4], null, new JMenuItem("Exit", 'x') },
						menuListener));

		// Create Option Menu
		JMenu optionsMenu = new JMenu("Options");
		optionsMenu.setMnemonic('O');
		menuBar.add(ViewUtils.makeMenu(
				optionsMenu, new Object[] { new JMenuItem("Clear Console", 'C'),
						new JMenuItem("Console Settings...", 'S'), null, modelMenus[5], modelMenus[2], },
				menuListener));

		// Create Control Menu
		JMenu controlsMenu = new JMenu("Controls");
		controlsMenu.setMnemonic('C');
		menuBar.add(ViewUtils.makeMenu(controlsMenu, new Object[] { controlMenus[0], controlMenus[1], controlMenus[2],
				controlMenus[3], null, controlMenus[4], }, menuListener));

		JMenu helpMenu = new JMenu("Help");
		helpMenu.setMnemonic('H');
		menuBar.add(ViewUtils.makeMenu(helpMenu, new Object[] { new JMenuItem("About", 'A') }, menuListener));

		return menuBar;
	}

	private class MenuActionListener implements ActionListener {
		private View view;

		public MenuActionListener(View view) {
			this.view = view;
		}

		public void actionPerformed(java.awt.event.ActionEvent actionEvent) {
			String cmd = actionEvent.getActionCommand();
			if (cmd.equalsIgnoreCase("Save Tracking Log..."))
				saveTrackingReportAction();
			else if (cmd.equalsIgnoreCase("Save Console Log..."))
				saveConsoleLogAction();
			else if (cmd.equalsIgnoreCase("Export to CSV..."))
				exportCSVAction();
			else if (cmd.equalsIgnoreCase("Export to Encoded CSV..."))
				exportEncodedCSVAction();
			else if (cmd.equalsIgnoreCase("Console Settings..."))
				console.customizeComponent(PARENT_FRAME);
			else if (cmd.equalsIgnoreCase("Clear Console"))
				clearConsoleAction();
			else if (cmd.equalsIgnoreCase("Tracking Log Settings..."))
				tracking.trackingLogOption(PARENT_FRAME, cmd);
			else if (cmd.equalsIgnoreCase("Load Model..."))
				modelWizard.openDialog();
			else if (cmd.equalsIgnoreCase("Refresh Tracking Log"))
				tracking.trackingLogOption(PARENT_FRAME, cmd);
			else if (cmd.equalsIgnoreCase("Step"))
				controller.userGesture(controller.SIM_STEP_GESTURE, null);
			else if (cmd.equalsIgnoreCase("Step(n)")) {
				String val = JOptionPane.showInputDialog(View.PARENT_FRAME, "Number of steps to iterate: ");
				if (val != null)
					try {
						Integer i = new Integer(val);
						controller.userGesture(controller.SIM_STEPN_GESTURE, i);
					} catch (Exception exp) {
						System.err.println(exp);
					}
			} else if (cmd.equalsIgnoreCase("Run"))
				controller.userGesture(controller.SIM_RUN_GESTURE, null);
			else if (cmd.equalsIgnoreCase("Pause"))
				controller.userGesture(controller.SIM_PAUSE_GESTURE, null);
			else if (cmd.equalsIgnoreCase("Reset")) {
				String msg = "Reset this Model?\n";
				msg += "All Tracking Data Will Be Lost";
				int option = JOptionPane.showConfirmDialog(View.PARENT_FRAME, msg, "Reset Model?",
						JOptionPane.YES_NO_OPTION);
				if (option == JOptionPane.YES_OPTION)
					controller.userGesture(controller.SIM_RESET_GESTURE, null);
			} else if (cmd.equalsIgnoreCase("About"))
				showAboutBox();
			else if (cmd.equalsIgnoreCase("Exit")) {
				sim.saveModelLayout();
				System.exit(0);
			}
		}
	}

	private void showAboutBox() {
		splashScreen.showAsDialog(this, "About");
	}

	private void showSCAction() {
		try {
			if (simSCView.isIcon())
				simSCView.setIcon(false);
		} catch (Exception e) {
		}
		simSCView.setVisible(true);
		simSCView.moveToFront();
	}

	private void clearConsoleAction() {
		int option = JOptionPane.showConfirmDialog(this, "Clear All Console Data?", "Confirm Clear...",
				JOptionPane.YES_NO_OPTION);
		if (option == JOptionPane.YES_OPTION)
			console.clearConsole();
	}

	/**
	 * Load Model
	 */
	public void loadModelAction() {
		if (curPackages != null && modelName != null) {
			String[] val = { curPackages, modelName };
			if (isCAModel) {
				controller.userGesture(controller.LOAD_MODEL_ASYNC, val);
			} else {
				controller.userGesture(controller.LOAD_MODEL_GESTURE, val);
			}
		}
	}

	/**
	 * Reload a model
	 */
	private void reloadModelAction() {
		int option = JOptionPane.showConfirmDialog(this, "Reload current model? (All log data will be lost)",
				"Reload Model...", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
		if (option == JOptionPane.OK_OPTION) {
			String[] val = { curPackages, modelName };
			if (isCAModel) {
				controller.userGesture(controller.LOAD_MODEL_ASYNC, val);
			} else {
				controller.userGesture(controller.LOAD_MODEL_GESTURE, val);
			}
		}
	}

	private void setGridBagComponent(int x, int y, GridBagLayout gbl, GridBagConstraints gbc, JPanel panel,
			Component component) {
		gbc.gridx = x;
		gbc.gridy = y;
		gbl.setConstraints(component, gbc);
		panel.add(component);
	}

	private void exportCSVAction() {
		if (modelView.getSelectedModel() == null) {
			JOptionPane.showMessageDialog(this, "Cannot Export, No Model Selected.", "Please choose a model first...",
					JOptionPane.WARNING_MESSAGE);
			return;
		}
		JFileChooser chooser = new JFileChooser(currentDirectory);
		chooser.setDialogTitle("Export CSV Tracking Data (.csv)");
		if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
			currentDirectory = chooser.getCurrentDirectory().getAbsolutePath();
			String path = chooser.getSelectedFile().getAbsolutePath();
			String tst = path.toLowerCase();
			if (!(tst.endsWith(".csv")))
				path = path + ".csv";
			controller.userGesture(controller.EXPORT_TO_CSV_GESTURE, path);
		}
	}

	private void exportEncodedCSVAction() {
		if (modelView.getSelectedModel() == null) {
			JOptionPane.showMessageDialog(this, "Cannot Export, No Model Selected.", "Please choose a model first...",
					JOptionPane.WARNING_MESSAGE);
			return;
		}
		JFileChooser chooser = new JFileChooser(currentDirectory);
		chooser.setDialogTitle("Export Encoded CSV Tracking Data (.csv)");
		if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
			currentDirectory = chooser.getCurrentDirectory().getAbsolutePath();
			String path = chooser.getSelectedFile().getAbsolutePath();
			String tst = path.toLowerCase();

			String[] exportPaths = new String[2];

			if (tst.endsWith(".htm") || tst.endsWith(".html"))
				exportPaths[0] = path;
			else
				exportPaths[0] = path + ".html";

			if (tst.endsWith(".csv"))
				exportPaths[1] = path;
			else
				exportPaths[1] = path + ".csv";

			controller.userGesture(controller.EXPORT_TO_ENCODED_CSV_GESTURE, exportPaths);
		}
	}

	private void saveTrackingReportAction() {
		JFileChooser chooser = new JFileChooser(currentDirectory);
		chooser.setDialogTitle("Save Tracking Log (.html)");
		if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
			currentDirectory = chooser.getCurrentDirectory().getAbsolutePath();
			String path = chooser.getSelectedFile().getAbsolutePath();
			String tst = path.toLowerCase();
			if (!(tst.endsWith(".htm") || tst.endsWith(".html")))
				path = path + ".html";
			controller.userGesture(controller.SAVE_TRACKING_LOG_GESTURE, path);
		}
	}

	private void saveConsoleLogAction() {
		JFileChooser chooser = new JFileChooser(currentDirectory);
		chooser.setDialogTitle("Save Console Log (.txt)");
		if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
			currentDirectory = chooser.getCurrentDirectory().getAbsolutePath();
			String path = chooser.getSelectedFile().getAbsolutePath();
			String tst = path.toLowerCase();
			if (!tst.endsWith(".txt"))
				path = path + ".txt";
			controller.userGesture(controller.SAVE_CONSOLE_LOG_GESTURE, path);
		}
	}

	/**
	 * Add Tracking Column based on the output from the simulator
	 */
	public void addTrackingColumn(double currentTime) {
		tracking.addTracking(currentTime);

	}

	// added for CA, by Chao
	public void addCATrackingColumn(double currentTime) {
		catracking.addCATracking(currentTime);
	}

	public void addCATimeViewTrackingColumn(double currentTime) {
		catracking.addCALogTracking(currentTime);
		catracking.addCATimeViewTracking(currentTime);

	}

	/**
	 * Load Simulator
	 */
	public void loadSimulator(FSimulator simulator) {
		simulatorView.loadSimulator(simulator);
		simSCView.loadSimulator(simulator);
		modelView.loadModel(simulator.getRootModel());
		simPane.removeAll();
		simPane.repaint();
		sim.useModelClass(simulator.getRootModel(), getSourcePath());

		if (simulator instanceof FCASimulator) {
			isCAModel = true;
		} else {
			if (modelWizard.isCATracking()) {
				controller.closeLoadingWindow();
				JOptionPane.showMessageDialog(null, "This is not a CA Model!");
				catracking.closeSpaceView();
				controller.reload();
			}
			isCAModel = false;
		}

		if (isSimView()) {
			simPane.add(sim.getSimView());
		}

		if (isTracking()) {
			tracking.loadSimModel(simulator.getRootModel());
			this.removeExternalWindows();
		}

		// add for CA Checking, by Chao
		if (isCATracking()) {
			catracking.loadCAModel(simulator.getRootModel(), controller);
			this.removeExternalWindows();
		}
		// end adding

		for (int i = 0; i < ButtonControls.length; i++) {
			ButtonControls[i].setVisible(true);
		}

		for (int i = 0; i < modelMenus.length; i++) {
			modelMenus[i].setEnabled(true);
		}

		for (int i = 0; i < controlMenus.length; i++) {
			controlMenus[i].setEnabled(true);
		}
		controlMenus[3].setEnabled(false);
	}

	public void synchronizeView() {
		modelView.synchronizeView();
		simulatorView.synchronizeView();
		simSCView.synchronizeView();

	}

	// adding by Chao. Updating the Contorl Buttons and Simulation Status Text
	public void synchronizeCAView() {
		// after the simulation starts, use platform runlater to avoid
		// refreshing text too quickly to kill the javafx application
		if (!catracking.getCAView().isAtStartPoint()) {
			Platform.runLater(new Runnable() {
				@Override
				public void run() {
					catracking.getCAView().synchronizeView();
				}
			});
		} else {
			catracking.getCAView().synchronizeView();
		}
	}

	public String getConsoleLog() {
		return console.getTextString();
	}

	public JPanel getConsole() {
		return consolePane;
	}

	public void clearConsole() {
		console.clearConsole();
	}

	public void restartConsole() {
		console.redirectOutAndErrStreams();
	}

	public void simlationControl(String gesture) {
		if (isTracking())
			tracking.controlTimeView(gesture);
		if (isSimView())
			if (gesture.equals(ControllerInterface.SIM_RUN_GESTURE))
				SimView.modelView.runToOccur();
			else if (gesture.equals(ControllerInterface.SIM_STEP_GESTURE))
				SimView.modelView.stepToBeTaken();
		if (isCATracking()) {
			catracking.controlCATimeView(gesture);
		}
	}

	public SimView getSim() {
		return sim;
	}

	/*
	 * This is the start choice window
	 * 
	 * @author Chao
	 */
	private class StartChoice extends JDialog {
		public StartChoice() {
			this.setIconImage(new ImageIcon(ViewUtils.loadFullImage(ViewUtils.LOGO)).getImage());
			// StartChoice.this.setDefaultCloseOperation(EXIT_ON_CLOSE);
			JButton comp_btn = new JButton("Component Models");
			comp_btn.setPreferredSize(new Dimension(272, 138));

			JButton ca_btn = new JButton("Cellular Automata Models");
			ca_btn.setPreferredSize(new Dimension(272, 138));

			comp_btn.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					// System.out.println("I am clicked!");
					isCAModel = false;
					modelWizard.openDialog();

					StartChoice.this.dispose();

				}
			});

			String comp_tooltiptext = "<html>" + "<img src=\"" + ViewUtils.class.getResource("/graphics/DEVS-shot.png")
					+ "\" >" + "</html>";
			comp_btn.setToolTipText(comp_tooltiptext);

			ca_btn.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					// System.out.println("I am clicked!");
					isCAModel = true;
					modelWizard.openDialog();
					StartChoice.this.dispose();

				}
			});

			String ca_tooltiptext = "<html>" + "<img src=\"" + ViewUtils.class.getResource("/graphics/CA.png") + "\">"
					+ "</html>";
			ca_btn.setToolTipText(ca_tooltiptext);

			Container cont = this.getContentPane();

			cont.setLayout(new BorderLayout());
			cont.add(
					new JLabel("<html>" + "<img src=\""
							+ ViewUtils.class.getResource("/graphics/DEVS-SuiteLogo-small.png") + "\" >" + "</html>"),
					BorderLayout.PAGE_START);
			cont.add(comp_btn, BorderLayout.LINE_START);
			cont.add(ca_btn, BorderLayout.LINE_END);
			this.pack();
			this.setVisible(true);

		}
	}

	public void removeExternalWindows() {
		tracking.clearWindows();
		try {
			catracking.clearWindows();
		} catch (Exception e) {

		}
		//catracking.getCAView().getTrackingLogViewer().getDialogStage().close();
		catracking.closeSpaceView();
	}

	public String getLastModelViewed() {
		return this.lastModelViewed;
	}

	public void setLastModelViewed(String lastModelViewed) {
		this.lastModelViewed = lastModelViewed;
	}

	public String getSourcePath() {
		return modelWizard.getSourcePath();
	}

	public static boolean isSimView() {
		if (modelWizard == null) {
			return false;
		} else {
			return modelWizard.isSimView();
		}
	}

	public static boolean isTracking() {
		if (modelWizard == null) {
			return false;
		} else {
			return modelWizard.isTracking();
		}
	}

	public boolean isCATracking() {
		return this.modelWizard.isCATracking();
	}

	public CATrackingControl getCatracking() {
		return catracking;
	}
}
