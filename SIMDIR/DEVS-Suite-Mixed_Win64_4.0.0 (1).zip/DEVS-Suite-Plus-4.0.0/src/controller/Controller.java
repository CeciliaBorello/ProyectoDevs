/*     
 *    
 *  Author     : ACIMS(Arizona Centre for Integrative Modeling & Simulation)
 *  Version    : DEVSJAVA 2.7 
 *  Date       : 08-15-02 
 */
package controller;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

//Collections Connections

//Standard Java API Imports
import java.io.File;
import java.io.FileWriter;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.List;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.UIManager;

import GenCol.entity;

/**
 * Controller.java
 * This class provides control function for the Tracking Environment	
 * Created on September 18, 2002, 4:18 PM
 * Modified with the integration of DEVSJAVA on May 29, 2008
 */

//M&S Connections (for load)//CREATE FACADE LOADER!!
import facade.modeling.FModel;
import facade.simulation.FCoupledSimulator;
import facade.simulation.FSimulator;
import facade.simulation.CAsimulation.FCASimulator;
import facade.simulation.hooks.SimulatorHookListener;
import model.modeling.atomic;
import model.modeling.CAModels.TwoDimCellSpace;
import util.classUtils.DevsClassFileReader;
import view.View;
import view.ViewInterface;
import view.ViewUtils;
import view.CAView.SpaceView;
import view.modeling.ViewableAtomic;
import view.modeling.ViewableDigraph;
import view.simView.SimView;

public class Controller implements ControllerInterface, SimulatorHookListener {
	private FSimulator simulator;
	private ViewInterface view;
	private JDialog frm;
	private short modelType;
	private TrackingDataHandler trackingDataHandler;
	protected ViewableDigraph instanceModel;
	static int sc;

	public static void main(String[] args) {
		new Controller();
		System.out.println("Welcome to the DEVS-Suite Simulation Environment!");
		System.out.println("To Begin, Select [Load Model...] From The [File] Menu");
	}

	public Controller() {
		view = new View(this);
		view.createLoadPage();
	}

	public void reload() {
		view.createLoadPage();
		view.restartConsole();

		// view.removeExternalWindows();
	}

	public void injectInputGesture(FModel model, String portName, entity input) {
		model.injectInput(portName, input);
	}

	public void userGesture(String gesture, Object params) {
		try {
			if (gesture.equals(SIM_RUN_GESTURE)) {
				view.simlationControl(SIM_RUN_GESTURE);
				simulator.run();
				Stopwatch.start();
			} else if (gesture.equals(SIM_STEP_GESTURE)) {
				view.simlationControl(SIM_STEP_GESTURE);
				simulator.step();
			} else if (gesture.equals(SIM_STEPN_GESTURE)) {
				view.simlationControl(SIM_STEPN_GESTURE);
				simulator.step(((Integer) params).intValue());
			} else if (gesture.equals(SIM_PAUSE_GESTURE)) {
				view.simlationControl(SIM_PAUSE_GESTURE);
				simulator.requestPause();
			} else if (gesture.equals(SIM_RESET_GESTURE)) {
				// add by Chao for CAView
				if (view.isCATracking()) {
					view.getCatracking().getCAView().reset();					
				}
				view.simlationControl(SIM_RESET_GESTURE);
				simulator.reset();
				tabbedPanel();
				view.loadSimulator(simulator);
				view.synchronizeView();
				Governor.reset();
				view.removeExternalWindows();

			} else if (gesture.equals(SIM_SET_RT_GESTURE))
				simulator.setRTMultiplier(((Double) params).doubleValue());
			else if (gesture.equals(SIM_SET_TV_GESTURE))
				Governor.setTV(((Double) params).doubleValue());
			else if (gesture.equals(SAVE_TRACKING_LOG_GESTURE))
				writeString((String) params, trackingDataHandler.getHTMLTrackingLog());
			else if (gesture.equals(SAVE_CONSOLE_LOG_GESTURE))
				writeString((String) params, view.getConsoleLog());
			else if (gesture.equals(LOAD_MODEL_GESTURE)) {
				tabbedPanel();
				loadModel((String[]) params);
				try {
					view.removeExternalWindows();
				} catch (Exception e) {

				}
			} else if (gesture.equals(LOAD_MODEL_ASYNC)) {
				tabbedPanel();
				/*
				 * Start the Progress Bar for Loading Model
				 */
				frm = new JDialog();
				frm.setUndecorated(true);
				frm.setAlwaysOnTop(true);
				// frm.setModal(true);
				// frm.setOpacity(0.5f);
				frm.setBackground(new Color(255, 255, 255, 150));
				JPanel ProgressPanel = new JPanel();
				ProgressPanel.setLayout(new BoxLayout(ProgressPanel, BoxLayout.Y_AXIS));
				ProgressPanel.add(Box.createVerticalGlue());
				ProgressPanel.setOpaque(false);
				// ProgressPanel.add(new JLabel("<html><br/>" + "<font
				// size=\"4\"> &nbsp;&nbsp;Loading Model... </font>" +
				// "</html>"));
				ProgressPanel.add(Box.createVerticalGlue());
				ProgressPanel.add(new JLabel("<html>" + "<img src=\""
						+ ViewUtils.class.getResource("/graphics/loading2.gif") + "\" >" + "</html>"));
				frm.getContentPane().add(ProgressPanel);
				frm.pack();
				frm.setLocationRelativeTo(null);
				frm.setVisible(true);
				// frm.setSize(300, 200);

				frm.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);

				final SwingWorker worker = new SwingWorker() {
					@Override
					protected Void doInBackground() throws Exception {
						// Have the model loading inside the swingworker
						loadModel((String[]) params);
						return null;
					}
				};
				worker.addPropertyChangeListener(new PropertyChangeListener() {

					@Override
					public void propertyChange(PropertyChangeEvent pcEvt) {
						if (pcEvt.getNewValue() == SwingWorker.StateValue.DONE) {
							try {
								worker.get();
								frm.setVisible(false);
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
					}
				});
				worker.execute();

				try {
					view.removeExternalWindows();
				} catch (Exception e) {

				}
			} else if (gesture.equals(EXPORT_TO_CSV_GESTURE))
				writeString((String) params, trackingDataHandler.getCSVExport());
			else if (gesture.equals(EXPORT_TO_ENCODED_CSV_GESTURE)) {
				String[] data = trackingDataHandler.getEncodedCSVExport();
				String[] paths = (String[]) params;
				writeString(paths[0], data[0]);
				writeString(paths[1], data[1]);
			}
		} catch (Exception e) {
			System.err.println(e);
			e.printStackTrace();
		}
	}

	public void tabbedPanel() {
		// remove Tabs
		View.tabbedPane.removeAll();
		View.tabbedPane.add(view.getConsole(), 0);
		View.tabbedPane.setTitleAt(0, "Console");
		view.clearConsole();
	}

	public void systemExitGesture() {
		System.exit(0);
	}

	public void postComputeInputOutputHook() {

		// This prevent the slow of the simulation
		if (View.isTracking()) {
			view.addTrackingColumn(simulator.getTimeOfNextEvent());
			view.synchronizeView();
		} else if (view.isCATracking()) {
			view.addCATimeViewTrackingColumn(simulator.getTimeOfNextEvent());
		}
		view.synchronizeView();

	}

	// this is run after simulation step, so it will be getTimeOfLastEvent
	public void CAPostComputeInputOutputHook() {
		if (view.isCATracking()) {
			view.addCATrackingColumn(simulator.getTimeOfLastEvent());
			view.synchronizeCAView();
		}
	}

	public void simulatorStateChangeHook() {
		// This prevent the slow of the simulation
		if (view.isCATracking()) {
			view.synchronizeCAView();
		}
		view.synchronizeView();
	}

	// Params[0] = Model Package
	// Params[1] = Model Class Name
	// Model is loaded using a URLClassLoader
	private void loadModel(String[] params) {
		try {

			// adding by Chao, if it is CA View Tracking Mode, do not display
			// Swing
			if (View.isCAModel != true || !view.isCATracking()) {
				view.setSwingVisible(true);

			} else {
				view.setSwingVisible(false);
				// view.setSwingVisible(true);
			}

			Object instance;

			try {
//				view.clearConsole();
//				URL urlList[] = { new File(System.getProperty("user.dir")).toURL() };
//
//				ClassLoader loader = new URLClassLoader(urlList);
//
//				Class modelClass = loader.loadClass(params[0] + "." + params[1]);

				instance = DevsClassFileReader.readClass(
				        params[0].replace('/', '.').replace('\\', '.'), 
				        params[1]
				).getDeclaredConstructor().newInstance();
			} catch (Exception en) {
				en.printStackTrace();
				return;
			}

			if (instance instanceof ViewableAtomic) {
				instanceModel = new ViewableDigraph("ViewableAtomic");
				instanceModel.add((atomic) instance);
				// for each of the names of the outports of the atomic

				ViewableAtomic atomic = (ViewableAtomic) instance;
				List names = atomic.getOutportNames();
				for (int i = 0; i < names.size(); i++) {
					String portName = (String) names.get(i);

					// add an outport with this port name to the wrapper
					// digraph,
					// and couple it to the atomic's outport of this name,
					// so that outputs from that outport will be visible
					// when they are emitted
					instanceModel.addOutport(portName);
					instanceModel.addCoupling(atomic, portName, instanceModel, portName);
				}

				modelType = FModel.ATOMIC;
			} else if (instance instanceof ViewableDigraph) {
				instanceModel = (ViewableDigraph) instance;
				modelType = FModel.COUPLED;
			}

			simulator = new FCoupledSimulator(instanceModel, SimView.modelView, modelType);

			// add by Chao
			if (instance instanceof TwoDimCellSpace) {
				instanceModel = (TwoDimCellSpace) instance;
				simulator = new FCASimulator((TwoDimCellSpace) instanceModel, SimView.modelView, modelType);
			}
			// end of adding

			simulator.setSimulatorHookListener(this);
			view.loadSimulator(simulator);
		} catch (Exception e) {
			System.err.println("An Error Occured While Loading Model: " + e);
			e.printStackTrace();
		}
	}

	private void writeString(String path, String stringToWrite) {
		try {
			FileWriter fw = new FileWriter(path);
			fw.write(stringToWrite);
			fw.close();
		} catch (Exception e) {
			System.err.println("An Error Occured While Writing: " + path);
			System.err.println(e);
		}
	}

	public void registerTrackingDataHandler(TrackingDataHandler trackingHandler) {
		trackingDataHandler = trackingHandler;
	}

	public FSimulator getSimulator() {

		return this.simulator;
	}

	public void closeLoadingWindow() {
		try {
			frm.setVisible(false);
		} catch (Exception e) {

		}
	}
}
