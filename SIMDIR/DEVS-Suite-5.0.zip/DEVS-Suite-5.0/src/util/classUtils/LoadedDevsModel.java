package util.classUtils;

import view.modeling.ViewableDigraph;

public final class LoadedDevsModel
{
    public short modelType;
    public ViewableDigraph instanceModel;
}
