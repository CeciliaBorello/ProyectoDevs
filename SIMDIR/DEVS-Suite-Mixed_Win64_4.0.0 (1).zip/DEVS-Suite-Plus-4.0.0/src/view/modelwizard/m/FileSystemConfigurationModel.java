package view.modelwizard.m;

import java.util.ArrayList;
import java.util.List;

import view.modelwizard.c.FileSystemConfigurationController;

public class FileSystemConfigurationModel
{
	private FileSystemConfigurationController controller;
	private String classPath, sourcePath, packagesAreaText;
	
	final public String SETTINGS_FILE_NAME = "SimView_settings";
	
	public FileSystemConfigurationModel(FileSystemConfigurationController controller)
	{
		this.controller = controller;
	}
	
	public void setClassPath(String classPath)
	{
		this.classPath = classPath;
		this.controller.refreshClassPathFieldFromModel();
	}
	
	public String getClassPath()
	{
		return this.classPath;
	}
	
	public void setSourcePath(String sourcePath)
	{
		this.sourcePath = sourcePath;
		this.controller.refreshSourcePathFieldFromModel();
	}
	
	public void setPackagesAreaText(String packagesAreaText)
	{
		this.packagesAreaText = packagesAreaText;
		this.controller.refreshPackageAreaFieldFromModel();
	}
	
	public String getSourcePath()
	{
		return this.sourcePath;
	}
	
	public String getPackagesAreaText()
	{
		return this.packagesAreaText;
	}
}
