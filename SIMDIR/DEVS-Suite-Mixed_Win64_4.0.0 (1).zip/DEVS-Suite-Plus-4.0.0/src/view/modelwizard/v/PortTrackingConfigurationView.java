package view.modelwizard.v;

import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class PortTrackingConfigurationView extends JPanel
{
	private static final long serialVersionUID = 808115302906493450L;
	private PortTableView portTable;
	
	public PortTrackingConfigurationView(String name, String[] units, boolean[] portsStacked, boolean[] portsSeparate, List<String> portNames)
	{
		this.setLayout(new BoxLayout(this, BoxLayout.X_AXIS));


		Object col[] = { name, "Units", "Stack", "Separate" };
		Object[][] data = new Object[portNames.size()][4];

		int row = 0;
		for (int i = 0; i < portNames.size(); i++)
		{

			data[row][0] = String.valueOf(portNames.get(i));
			data[row][1] = units[i];
			data[row][2] = portsStacked[i];
			data[row][3] = portsSeparate[i];
			row++;
		}

		portTable = new PortTableView(data, col, portsStacked, portsSeparate, units);

		JScrollPane scrollPane = new JScrollPane(portTable);
		
		JPanel inset = new JPanel();
		inset.add(scrollPane);
		
		JScrollPane spane = new JScrollPane(inset);
		spane.setBorder(BorderFactory.createTitledBorder(name + "/Unit"));
		
		this.add(spane);
	}
}
