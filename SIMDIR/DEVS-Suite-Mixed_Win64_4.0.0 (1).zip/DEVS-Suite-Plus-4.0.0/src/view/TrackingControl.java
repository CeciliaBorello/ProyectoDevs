/* 
 * 
 *  Version    : DEVSJAVA 2.7 
 *  Date       : 08-15-02 
 */
/**
 * Tracking Control class: extracted from ModelTrackingComponent to integrate the TimeView
 * @author Sungung Kim
 */

package view;

import facade.modeling.*;

import java.awt.*;
import java.util.ArrayList;

import java.util.List;


import javax.swing.JOptionPane;

import view.timeView.*;
import view.timeView.Event;

public class TrackingControl
{

	private boolean isTrackingLogSelected = false;
	private int cntModel = 0;
	private final int TRACKING_LOG_INDEX = 1;
	protected static TimeView[] timeView;
	static int tc;
	// added

	protected ArrayList graphList = null;
	private List allModels;
	private List<Event> dataTimeView;
	private static Tracker[] modelColumn;
	private static ModelTrackingComponent modelTracking;
	private static String rootModelName;

	protected static ArrayList<ExternalTimeView> windowHandles = new ArrayList<ExternalTimeView>(0);

	public void controlTimeView(String control)
	{

		if (control == "Reset")
		{
			isTrackingLogSelected = false;
		}
		else
		{
			for (int i = 0; i < modelColumn.length; i++)
			{
				// In the case of reset, close the TimeView and TrackingLog
				if (modelColumn[i].isTimeViewSelected())
				{
					timeView[i].clock.start();
				}
			}
		}
	}

	public void addTracking(double currTime)
	{

		for (int i = 0; i < modelColumn.length; i++)
		{
			if (!isTrackingLogSelected)
			{
				isTrackingLogSelected = modelColumn[i].isTrackingSelected();
			}

			if (modelColumn[i].isTimeViewSelected())
			{
				dataTimeView = modelColumn[i].getCurrentTimeViewData(currTime);
				for (int j = 0; j < dataTimeView.size(); j++)
				{
					tc++;
					// System.out.println("addingevents^^^^^^^^^^"+(dataTimeView.get(j)));
					timeView[i].addEvent(dataTimeView.get(j));
				}
				timeView[i].endTime(currTime);
			}
		}
		if (isTrackingLogSelected)
		{
			modelTracking.addTrackingSet(currTime);
		}

	}

	public void loadSimModel(FModel rootModel)
	{
		cntModel = 0;
		rootModelName = rootModel.getName();
		if (rootModel instanceof FAtomicModel)
		{
			allModels = new ArrayList(1);
			allModels.add(new Tracker(rootModel, 0));
			cntModel++;
		} else
		{
			allModels = createTrackersForModelHierarchy((FCoupledModel) rootModel);
		}

		modelColumn = (Tracker[]) allModels.toArray(new Tracker[allModels.size()]);

		// Initialize
		timeView = new TimeView[cntModel];
		// chartView = new ChartView[cntModel];
		dataTimeView = new ArrayList(1);
		
	}

	private List<Tracker> createTrackersForModelHierarchy(FCoupledModel model)
	{
		List<Tracker> list = new ArrayList<Tracker>();
		list.add(new Tracker(model, cntModel));
		cntModel++;
		for (FModel child : (List<FModel>) model.getChildren())
		{
			if (child instanceof FAtomicModel)
			{
				list.add(new Tracker(child, cntModel));
				cntModel++;
			}
			else if (child instanceof FCoupledModel)
			{
				list.addAll(createTrackersForModelHierarchy((FCoupledModel) child));
			}
			// else error
		}
		return list;
	}

	public void trackingLogOption(Component owner, String option)
	{
		if (option.equalsIgnoreCase("Tracking Log Settings..."))
		{
			for (int i = 0; i < modelColumn.length; i++)
			{
				if (!isTrackingLogSelected)
				{
					isTrackingLogSelected = modelColumn[i].isTrackingSelected();
				}
			}

			if (isTrackingLogSelected)
			{
				modelTracking.customizeComponent(owner);
			} else
			{
				JOptionPane.showMessageDialog(null, "You need to select the tracking log first!", "Warning",
						JOptionPane.WARNING_MESSAGE);
			}
		}
		else if (option.equalsIgnoreCase("Refresh Tracking Log"))
		{
			modelTracking.refresh();
		}
	}

	public Tracker findTrackerFor(FModel model)
	{
		for (Tracker tracker : modelColumn)
		{
			if (tracker.getAttachedModel() == model)
			{
				return tracker;
			}
		}
		return null;
	}

	public void registerTrackingLog(ModelTrackingDataHandler trackingHandler)
	{
		modelTracking = new ModelTrackingComponent();
		modelTracking.loadModel(rootModelName, modelColumn);

		// If there exist the same tab, remove it
		if (View.tabbedPane.getTabCount() != 1 && // if there is another tab
													// except console
				View.tabbedPane.getTitleAt(TRACKING_LOG_INDEX).equalsIgnoreCase("Tracking Log"))
			View.tabbedPane.remove(TRACKING_LOG_INDEX);
		// Add a tab
		View.tabbedPane.add(modelTracking.getControl(), TRACKING_LOG_INDEX);
		View.tabbedPane.setTitleAt(TRACKING_LOG_INDEX, "Tracking Log");

		trackingHandler.registerTrackingComponent(modelTracking);
	}

	public void registerTimeView(ArrayList graphs, final int num, String XLabel, String TimeIncre, boolean isBreakout)
	{
		timeView[num] = new TimeView(graphs, modelColumn[num].getAttachedModel().getName(), XLabel, TimeIncre);

		// If there exist the same tab, remove it
		for (int i = 0; i < View.tabbedPane.getTabCount(); i++)
		{
			if (View.tabbedPane.getTitleAt(i).contains(modelColumn[num].getAttachedModel().getName()))
			{
				View.tabbedPane.remove(i);
			}
		}

		ArrayList<GraphsScrollComponent> tv = timeView[num].retTG();
		if (!isBreakout) // BREAK OUT CONTROLS
		{
			// Add a tab
			String graphName = "";
			for(GraphsScrollComponent gs : tv)
			{
				if (gs.getGraphs().size() > 1) {
					graphName = "_Stack";
				} else {
					graphName = "_" + gs.getGraphNames()[0];
				}
				
				View.tabbedPane.add(modelColumn[num].getAttachedModel().getName() + graphName, gs);
			}
		} 
		else
		{
			// make a separate window
			for(GraphsScrollComponent gs : tv)
			{
				ExternalTimeView ETV = new ExternalTimeView(modelColumn[num].getAttachedModel().getName() , gs);
				windowHandles.add(ETV);
				javax.swing.SwingUtilities.invokeLater(ETV);
			}
		}
		graphList = graphs;
	}

	public List<Tracker> getTrackers()
	{
		return (List<Tracker>) this.allModels;
	}

	public void clearWindows()
	{
		while (windowHandles.size() > 0)
		{
			windowHandles.remove(0).dispose();
		}
	}

}
