package view.modelwizard.v;

import java.awt.Dimension;
import java.util.List;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;

import view.View;
import view.modelwizard.c.ModelAndPackageController;
import view.modelwizard.m.ModelAndPackageModel;

public class ModelAndPackageView extends JPanel
{
	private static final long serialVersionUID = 7861250654784122120L;
	private ModelAndPackageController controller;
	private JPanel packagesPanel, modelsPanel;
	private JComboBox<String> packagesBox, modelsBox;
	private InitialConfigurationPageView parent;
	
	public ModelAndPackageView(InitialConfigurationPageView parent)
	{
		this.parent = parent;
		createController();
		this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        this.add(Box.createRigidArea(new Dimension(15,15)));
        
		packagesPanel = new JPanel();
		
		packagesPanel.setLayout(new BoxLayout(packagesPanel, BoxLayout.X_AXIS));
		packagesPanel.add(new JLabel("Package: "));
        
        packagesBox = new JComboBox<String>();
        
        // this keeps the combo-box from taking up extra height
        // unnecessarily under JRE 1.4
        packagesBox.setMaximumSize(new Dimension(packagesBox.getMaximumSize().width,
		packagesBox.getMinimumSize().height));

        // when the a choice is selected from the packages combo-box
        packagesBox.addActionListener(this.getController().onPackagesBoxChange);
        packagesPanel.add(packagesBox);
        
        populatePackagesBox();
        
        this.add(packagesPanel);
        
        modelsPanel = new JPanel();
        
        modelsPanel.setLayout(new BoxLayout(modelsPanel, BoxLayout.X_AXIS));
        modelsPanel.add(Box.createRigidArea(new Dimension(15,1)));
        modelsPanel.add(new JLabel("Model: "));
        
        modelsBox = new JComboBox<String>();
        modelsBox.setMaximumSize(new Dimension(modelsBox.getMaximumSize().width, modelsBox.getMinimumSize().height));
        
        modelsBox.addActionListener(this.getController().onModelsBoxChange);
        
        modelsPanel.add(modelsBox);
        this.add(modelsPanel);
	}
	
	public void createController()
	{
		this.controller = new ModelAndPackageController(this);
	}
	
	public ModelAndPackageController getController()
	{
		return this.controller;
	}
	
	public InitialConfigurationPageView getParentView()
	{
		return this.parent;
	}
	
    public void populatePackagesBox()
    {
        packagesBox.removeAllItems();

        packagesBox.addItem("Select a package");
      	      
        // if the user has specified a list of model packages
        if (!isPackagesListEmpty())
        {
        	for(String packageName : getPackagesList())
        	{
        		packagesBox.addItem(packageName);
        	}
        }
    }
    
    public void populateModelsBox()
    {
    	modelsBox.removeAllItems();
    	
    	if (!isPackagesListEmpty() && !isModelsListEmpty())
    	{
    		for(String modelName : getModelsList())
    		{
    			modelsBox.addItem(modelName);
    		}
    	}
    }
    
    public boolean isModelSelected()
    {
    	return modelsBox.getSelectedIndex() > 0;
    }
    
    public ModelAndPackageModel getModel()
    {
    	return this.getController().getModel();
    }
    
    private boolean isPackagesListEmpty()
    {
    	return this.getModel().isPackagesListEmpty();
    }
    
    private boolean isModelsListEmpty()
    {
    	return this.getModel().isPackagesListEmpty();
    }
    
    private List<String> getPackagesList()
    {
    	return this.getModel().getPackagesList();
    }
    
    private List<String> getModelsList()
    {
    	return this.getModel().getModelsList();
    }
    
    public JComboBox<String> getModelsBox()
    {
    	return this.modelsBox;
    }
    
    public JComboBox<String> getPackagesBox()
    {
    	return this.packagesBox;
    }
    
    public String getSelectedModel()
    {
    	return (String) this.modelsBox.getSelectedItem();
    }
    
    public void setSelectedModel(String selectedModel)
    {
    	this.modelsBox.setSelectedItem(selectedModel);
    }
    
    public void setSelectedPackage(String selectedPackage)
    {
    	this.packagesBox.setSelectedItem(selectedPackage);
    }
    
    public String getSelectedPackage()
    {
    	return (String) this.packagesBox.getSelectedItem();
    }
}
