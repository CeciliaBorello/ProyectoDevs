package view.modelwizard.c;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.List;

import view.View;
import view.modelwizard.m.FileSystemConfigurationModel;
import view.modelwizard.v.FileSystemConfigurationView;
import view.modelwizard.v.InitialConfigurationPageView;

public class FileSystemConfigurationController
{
	private FileSystemConfigurationView view;
	private FileSystemConfigurationModel model;
	
	public FileSystemConfigurationController(FileSystemConfigurationView view)
	{
		this.view = view;
		
		this.model = new FileSystemConfigurationModel(this);
		getParentView().getModel().fileSystemConfiguration = this.model;
		
		loadSettings();
	}
	
	public FileSystemConfigurationModel getModel()
	{
		return this.model;
	}
	
	private InitialConfigurationPageView getParentView()
	{
		return this.view.getParentView();
	}
	
	public void refreshClassPathFieldFromModel()
	{
		if(view.getClassPathField() != null)
		{
			view.getClassPathField().setText(model.getClassPath());
		}
	}
	
	public void refreshSourcePathFieldFromModel()
	{
		if(view.getSourcePathField() != null)
		{
			view.getSourcePathField().setText(model.getSourcePath());
		}
	}
	
	public void refreshPackageAreaFieldFromModel()
	{
		if(view.getPackagesArea() != null)
		{
			view.getPackagesArea().setText(model.getPackagesAreaText());
			updateModelAndPackageView();
		}
	}
	
	public void submitConfiguration()
	{
		// store the class path field entry
		model.setClassPath(view.getClassPathField().getText());
    	
        if (model.getClassPath().equals("")) {
        	model.setClassPath(".");
        }
        model.setClassPath(removeTrailingString(model.getClassPath(), "/"));
        
        // store the source path field entry
        model.setSourcePath(view.getSourcePathField().getText());
        if (model.getSourcePath().equals("")) {
        	model.setSourcePath(".");
        }
        model.setSourcePath(removeTrailingString(model.getSourcePath(), "/"));

        updateModelAndPackageView();
        
        view.setInvisible();
        
        saveSettings();
	}
	
	public void updateModelAndPackageView()
	{
		String packagesAreaText = view.getPackagesArea().getText();
		String lastSelectedPackage = View.curPackages;
		String lastSelectedModel = getParentView().getParentView().getLastModelViewed();
		
        this.getParentView().getModelAndPackageView().getController().update(packagesAreaText, lastSelectedPackage, lastSelectedModel);
	}
	
	public String removeTrailingString(String s, String trailing)
	{
		if(s.endsWith(trailing))
		{
			return s.substring(0, s.length() - trailing.length());
		}
		else
		{
			return s;
		}
	}
	
	public ActionListener onOkPressed = new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            submitConfiguration();
        }
    };
    
    /**
     * Loads this program's settings from its settings files.
    */
    private void loadSettings()
    {
        try {
            // read in the settings from the settings file
            InputStream in = new FileInputStream(model.SETTINGS_FILE_NAME);
            ObjectInputStream s = new ObjectInputStream(in);
            model.setClassPath((String) s.readObject());
            this.readPackagesArea(s);
            View.curPackages = (String)s.readObject();	            
            getParentView().getParentView().setLastModelViewed((String)s.readObject());
            model.setSourcePath((String)s.readObject());
        } catch (Exception e) {
            System.out.println("Couldn't read settings from file.");
        }
    }
    
    private void readPackagesArea(ObjectInputStream s) throws ClassNotFoundException, IOException, ClassCastException
    {
        Object packagesArea = s.readObject();
        try
        {
        	model.setPackagesAreaText((String) packagesArea);            
        }
        catch(ClassCastException e)
        {
        	model.setPackagesAreaText(listToString((List<String>) packagesArea));
        }
    }
    
    private String listToString(List<String> stringList)
    {
    	StringBuffer sb = new StringBuffer();
    	for(String str : stringList)
    	{
    		sb.append(str)
    		  .append("\n");
    	}
    	
    	sb.deleteCharAt(sb.length() - 1);
    	
    	return sb.toString();
    }

    public void saveSettings()
    {
        try {
            // write out the current settings to the settings file
            FileOutputStream out = new FileOutputStream(model.SETTINGS_FILE_NAME);
            ObjectOutputStream s = new ObjectOutputStream(out);
            s.writeObject(model.getClassPath());
            s.writeObject(view.getPackagesArea().getText());
            s.writeObject(View.curPackages);
            s.writeObject(getParentView().getParentView().getLastModelViewed());
            s.writeObject(model.getSourcePath());
            s.flush();
            s.close();
        } catch (IOException e) {e.printStackTrace();}
    }
}
