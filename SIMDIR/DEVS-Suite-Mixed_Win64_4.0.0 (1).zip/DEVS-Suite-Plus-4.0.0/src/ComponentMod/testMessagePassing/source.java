package ComponentMod.testMessagePassing;

import java.lang.*;

import GenCol.*;
import model.modeling.*;
import model.simulation.*;
import view.modeling.ViewableAtomic;
import view.simView.*;
import view.modeling.ViewableComponent;

public class source extends ViewableAtomic {

	protected double int_arr_time;
	protected int count;
	protected String job_name;

	public source() {
		this("source", 10, "job");
	}

	public source(String name, double Int_arr_time, String job_name) {
		super(name);
		addInport("in");
		addOutport("out");

		int_arr_time = Int_arr_time;
		this.job_name = job_name;

	}

	public void initialize() {
		holdIn("active", int_arr_time);

		// phase = "passive";
		// sigma = INFINITY;
		sigma = 0;
		count = 0;
		super.initialize();
	}

	public void deltext(double e, message x) {
		Continue(e);
		if (!phaseIs("active")) {
			for (int i = 0; i < x.getLength(); i++)
				if (messageOnPort(x, "in", i)) {

					holdIn("active", int_arr_time);
				}
		}
	}

	public void deltint() {

		if (phaseIs("active")) {
			count = count + 1;

			holdIn("waiting", 0);
		} else
			passivate();
	}

	public message out() {

		// System.out.println(name+" out count "+count);

		message m = new message();
		if (!phaseIs("waiting")) {
			content con = makeContent("out", new entity(job_name + count));
			m.add(con);
		}

		return m;
	}

	public void showState() {
		super.showState();
		System.out.println("int_arr_t: " + int_arr_time);
	}

	public String getTooltipText() {
		return super.getTooltipText() + "\n" + " int_arr_time: " + int_arr_time + "\n" + " count: " + count;
	}

}
