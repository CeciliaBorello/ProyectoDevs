package view.modelwizard.c;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;

import javax.swing.tree.DefaultMutableTreeNode;

import facade.modeling.FModel;
import view.Tracker;
import view.modelwizard.ModelHierarchyRenderer;
import view.modelwizard.m.ComponentTrackingOptionsModel;
import view.modelwizard.v.ComponentTrackingOptionsView;
import view.timeView.Graph;
import view.timeView.GraphFactory;

public class ComponentTrackingOptionsController
{
	private ComponentTrackingOptionsView view;
	private ComponentTrackingOptionsModel model;
	
	public ComponentTrackingOptionsController(ComponentTrackingOptionsView view, Tracker tracker, FModel devsModel)
	{
		this.view = view;
		model = new ComponentTrackingOptionsModel(tracker, devsModel);
	}
	
	public ComponentTrackingOptionsModel getModel()
	{
		return this.model;
	}
	
	private void disableTrackButton()
	{
		this.view.disableTrackButton();
	}
	
	private DefaultMutableTreeNode getLastSelectedPathComponent()
	{
		return (DefaultMutableTreeNode) this.view.getParentView().getModelHierarchy().getLastSelectedPathComponent();
	}
	
	private boolean trackedNodesContains(DefaultMutableTreeNode node)
	{
		return this.view.getParentView().getModel().trackedNodesContains(node);
	}
	
	private void addTrackedNode(DefaultMutableTreeNode node)
	{
		this.view.getParentView().getModel().addTrackedNode(node);
	}
	
	private String getTimeIncrementText()
	{
		return this.view.getXAxisConfigurationView().getTimeIncrement().getText();
	}
	
	private String getXAxisUnitText()
	{
		return this.view.getXAxisConfigurationView().getXAxisUnit().getText();
	}
	
	private String[] getInputPortsUnits()
	{
		return this.model.getInputPortUnits();
	}
	
	private String[] getOutputPortsUnits()
	{
		return this.model.getOutputPortUnits();
	}
	
	private boolean isHTMLTrackingEnabled()
	{
		return this.view.getTrackingStyleView().isHTMLTrackingSelected();
	}
	
	private boolean isZeroTimeAdvanceChecked()
	{
		return this.view.getXAxisConfigurationView().isZeroTimeAdvanceChecked();
	}
	
	private boolean isTimeViewSelected()
	{
		return this.view.getTrackingStyleView().isTimeViewSelected();
	}
	
	private boolean isTimeViewSeparatedSelected()
	{
		return this.view.getTrackingStyleView().isTimeViewSeparatedSelected();
	}
	
	private void setCellRenderer()
	{
		this.view.getParentView().getModelHierarchy().setCellRenderer(new ModelHierarchyRenderer(view.getParentView()));
	}
	
	private Function<Integer, Boolean> inputPortStackedAt = new Function<Integer, Boolean>(){

        @Override
        public Boolean apply(Integer index)
        {
            return model.getTrackInputPortsStackedAt(index);
        }
	    
	};
	
	private Function<Integer, Boolean> inputPortSeparateAt = new Function<Integer, Boolean>(){

	    @Override
	    public Boolean apply(Integer index)
	    {
	        return model.getTrackInputPortsSeparateAt(index);
	    }

	};
	
    private Function<Integer, String> inputPortUnitsAt = new Function<Integer, String>(){

        @Override
        public String apply(Integer index)
        {
            return model.getInputPortUnit(index);
        }

    };
    
    private Function<Integer, String> inputPortNameAt = new Function<Integer, String>(){

        @Override
        public String apply(Integer index)
        {
            return model.getInputPortName(index);
        }

    };
	
	private Function<Integer, Boolean> outputPortStackedAt = new Function<Integer, Boolean>(){

	    @Override
	    public Boolean apply(Integer index)
	    {
	        return model.getTrackOutputPortsStackAt(index);
	    }

	};
	
    private Function<Integer, Boolean> outputPortSeparateAt = new Function<Integer, Boolean>(){

        @Override
        public Boolean apply(Integer index)
        {
            return model.getTrackOutputPortsSeparateAt(index);
        }

    };
    
    private Function<Integer, String> outputPortUnitsAt = new Function<Integer, String>(){

        @Override
        public String apply(Integer index)
        {
            return model.getOutputPortUnit(index);
        }

    };
    
    private Function<Integer, String> outputPortNameAt = new Function<Integer, String>(){

        @Override
        public String apply(Integer index)
        {
            return model.getOutputPortName(index);
        }

    };
    
    private Function<Integer, Boolean> stateStackedAt = new Function<Integer, Boolean>(){

        @Override
        public Boolean apply(Integer index)
        {
            return model.getTrackStateStackAt(index);
        }

    };
    
    private Function<Integer, Boolean> stateSeparateAt = new Function<Integer, Boolean>(){

        @Override
        public Boolean apply(Integer index)
        {
            return model.getTrackStateSeparateAt(index);
        }

    };
    
    private Function<Integer, String> stateUnitsAt = new Function<Integer, String>(){

        @Override
        public String apply(Integer index)
        {
            return model.getStateUnitAt(index);
        }

    };
    
    private Function<Integer, String> stateNameAt = new Function<Integer, String>(){

        @Override
        public String apply(Integer index)
        {
            return model.getStateNameAt(index);
        }

    };
    
    private Function<Integer, Boolean> timeStackedAt = new Function<Integer, Boolean>(){

        @Override
        public Boolean apply(Integer index)
        {
            return model.getTrackTimeDimensionStackAt(index);
        }

    };
    
    private Function<Integer, Boolean> timeSeparateAt = new Function<Integer, Boolean>(){

        @Override
        public Boolean apply(Integer index)
        {
            return model.getTrackTimeDimensionSeparateAt(index);
        }

    };
    
    private Function<Integer, String> timeUnitsAt = new Function<Integer, String>(){

        @Override
        public String apply(Integer index)
        {
            return model.getTimeUnitsAt(index);
        }

    };
    
    private Function<Integer, String> timeNameAt = new Function<Integer, String>(){

        @Override
        public String apply(Integer index)
        {
            return model.getTimeDimensionNameAt(index);
        }

    };
    
    private Consumer<Tracker> atLeastOneInputTracked = new Consumer<Tracker>() {

        @Override
        public void accept(Tracker tracker)
        {
            tracker.setatLeastOneInputTracked(true);
        }
        
    };
    
    private Consumer<Tracker> atLeastOneOutputTracked = new Consumer<Tracker>() {

        @Override
        public void accept(Tracker tracker)
        {
            tracker.setatLeastOneOutputTracked(true);
        }
        
    };
    
	private void processTrackingForTableView(ArrayList<Graph> graphs,
	            GraphFactory graphFactory,
	            Tracker tracker,
	            String[] categories,
	            List<String> trackedObjectNames,
	            Function<Integer, Boolean> stackedAt, 
	            Function<Integer, Boolean> separateAt,
	            Function<Integer, String> nameAt,
	            Function<Integer, String> unitAt,
	            Consumer<Tracker> atLeastOneTracked)
	{
	    String category = categories[0];
        for (int i = 0; i < trackedObjectNames.size(); i++)
        {
            if(i < categories.length)
            {
                category = categories[i];
            }
            if (stackedAt.apply(i) || separateAt.apply(i))
            {
                if(atLeastOneTracked != null)
                {
                    atLeastOneTracked.accept(tracker);
                }
                Graph g = graphFactory.createChart(category);
                g.setName(nameAt.apply(i));
                g.setCategory(category);
                g.setZeroTimeAdvance(isZeroTimeAdvanceChecked());
                g.setStacked(stackedAt.apply(i));
                graphs.add(g);
                if (unitAt.apply(i) != null)
                {
                    g.setUnit(unitAt.apply(i));
                }
                else
                {
                    g.setUnit("");
                }

            }
        }
	}
	
	public ActionListener onTrackPressed = new ActionListener() {
		public void actionPerformed(ActionEvent e)
		{
			disableTrackButton();
			DefaultMutableTreeNode node = getLastSelectedPathComponent();
			ArrayList<Graph> graphs = new ArrayList<Graph>();
			// add node in arrayList
			if (!trackedNodesContains(node))
			{
				addTrackedNode(node);
			}

			Tracker tracker = model.getTracker();
			setCellRenderer();
			
			tracker.settimeIncrement(getTimeIncrementText());
			tracker.setxUnit(getXAxisUnitText());

			if (!tracker.getTrackingLogSelected())
			{
				tracker.setTrackingLogSelected(isHTMLTrackingEnabled());

			}

			GraphFactory graphFactory = new GraphFactory();

            List<String> objectNames = model.getTimeDimensionNames();
            processTrackingForTableView(graphs, 
                                        graphFactory, 
                                        tracker, 
                                        new String[] {"STATEVARIABLE"}, 
                                        objectNames,
                                        timeStackedAt, 
                                        timeSeparateAt, 
                                        timeNameAt,
                                        timeUnitsAt,
                                        null);
			
			objectNames = model.getStateNames();
			processTrackingForTableView(graphs, 
			                            graphFactory, 
			                            tracker, 
			                            new String[] {"STATE", "SIGMA"}, 
			                            objectNames,
			                            stateStackedAt, 
			                            stateSeparateAt, 
			                            stateNameAt, 
			                            stateUnitsAt,
			                            null);

			tracker.setatLeastOneInputTracked(false);
			
			objectNames = model.getInputPortNames();
            processTrackingForTableView(graphs, 
                                        graphFactory, 
                                        tracker, 
                                        new String[] {"INPUT"}, 
                                        objectNames,
                                        inputPortStackedAt, 
                                        inputPortSeparateAt, 
                                        inputPortNameAt, 
                                        inputPortUnitsAt,
                                        atLeastOneInputTracked);

            tracker.setatLeastOneOutputTracked(false);
			
			objectNames = model.getOutputPortNames();
            processTrackingForTableView(graphs, 
                                        graphFactory, 
                                        tracker, 
                                        new String[] {"OUTPUT"}, 
                                        objectNames,
                                        outputPortStackedAt, 
                                        outputPortSeparateAt, 
                                        outputPortNameAt, 
                                        outputPortUnitsAt,
                                        atLeastOneOutputTracked);

			tracker.setGraphs(graphs);

			if (!tracker.getTimeViewSelected())
			{
				if (isTimeViewSelected() || isTimeViewSeparatedSelected())
				{
					tracker.setTimeViewSelected(true);
				}
			}
		}
	};
}
