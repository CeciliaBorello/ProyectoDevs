/*     
 *    
 *  Author     : ACIMS(Arizona Center for Integrative Modeling & Simulation)
 *  Version    : DEVS-Suite 3.0.0 
 *  Date       : 10-01-2017
 */

package ComponentMod.testMessagePassing;

import java.util.HashMap;
import java.util.Map;
import GenCol.doubleEnt;
import GenCol.entity;
import model.modeling.content;
import model.modeling.message;
import view.modeling.ViewableAtomic;
import GenCol.*;
import model.modeling.*;
import model.simulation.*;
import view.modeling.ViewableAtomic;
import view.simView.*;
import view.modeling.ViewableComponent;

public class target extends ViewableAtomic {
	protected Map arrived, solved;
	protected double observation_time;

	public target(String name, double Observation_time) {
		super(name);
		addInport("in");
		addOutport("out");

		observation_time = Observation_time;

		initialize();
	}

	public target() {
		this("target", 200);
	}

	public void initialize() {
		phase = "active";
		sigma = observation_time;
		super.initialize();
	}

	public void deltext(double e, message x) {
		Continue(e);
		entity val;
		for (int i = 0; i < x.size(); i++) {
			if (messageOnPort(x, "in", i)) {
				val = x.getValOnPort("in", i);
				holdIn(val.getName(), 0);
			}

		}

	}

	public void deltint() {
		passivate();
	}

	public message out() {
		message m = new message();
		content con = makeContent("out", new entity(phase));
		m.add(con);
		return m;
	}
}
