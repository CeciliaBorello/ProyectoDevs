package view.modelwizard.m;

import java.util.ArrayList;
import java.util.List;

import view.Tracker;

public class ModelWizardModel
{
	private ComponentTrackingConfigurationPageModel componentTrackingConfigModel;
	
	public void setComponentTrackingConfigModel(ComponentTrackingConfigurationPageModel componentTrackingConfigModel)
	{
		this.componentTrackingConfigModel = componentTrackingConfigModel;
	}
	
	public ComponentTrackingConfigurationPageModel getComponentTrackingConfigModel()
	{
		return this.componentTrackingConfigModel;
	}

}
