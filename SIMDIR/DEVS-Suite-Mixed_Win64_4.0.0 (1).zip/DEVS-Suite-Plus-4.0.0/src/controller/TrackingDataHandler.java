package controller;

import view.ModelTrackingComponent;

public interface TrackingDataHandler {	
	public String getCSVExport();
	public String[] getEncodedCSVExport();
	public String getHTMLTrackingLog();
}
